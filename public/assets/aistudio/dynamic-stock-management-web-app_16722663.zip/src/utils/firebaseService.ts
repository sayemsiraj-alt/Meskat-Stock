import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc,
  onSnapshot, 
  Firestore, 
  getDocs,
  limit,
  query
} from 'firebase/firestore';
import { SystemSettings } from '../data/mockData';

let appInstance: FirebaseApp | null = null;
let dbInstance: Firestore | null = null;

export const initFirebase = (settings: SystemSettings): Firestore | null => {
  if (!settings.firebaseApiKey || !settings.firebaseProjectId) {
    dbInstance = null;
    return null;
  }

  const firebaseConfig = {
    apiKey: settings.firebaseApiKey,
    authDomain: settings.firebaseAuthDomain || `${settings.firebaseProjectId}.firebaseapp.com`,
    projectId: settings.firebaseProjectId,
    storageBucket: settings.firebaseStorageBucket || `${settings.firebaseProjectId}.appspot.com`,
    messagingSenderId: settings.firebaseMessagingSenderId || '',
    appId: settings.firebaseAppId || ''
  };

  try {
    if (!getApps().length) {
      appInstance = initializeApp(firebaseConfig);
    } else {
      appInstance = getApp();
    }
    dbInstance = getFirestore(appInstance);
    return dbInstance;
  } catch (error) {
    console.error("Firebase initialization failed:", error);
    dbInstance = null;
    return null;
  }
};

export const testFirebaseConnection = async (settings: SystemSettings): Promise<{ success: boolean; message: string }> => {
  try {
    const db = initFirebase(settings);
    if (!db) {
      return { success: false, message: 'Please provide at least Firebase API Key and Project ID.' };
    }

    // Attempt a lightweight read operation to test connectivity
    const q = query(collection(db, '_connection_test'), limit(1));
    await getDocs(q);

    // Also write a connection heartbeat record
    await setDoc(doc(db, '_connection_test', 'status'), {
      connectedAt: new Date().toISOString(),
      appName: settings.brandName || 'Dear Health Care',
      status: 'Active'
    });

    return { success: true, message: `Successfully connected to Firebase Project "${settings.firebaseProjectId}"! Live Cloud Sync is Active.` };
  } catch (err: any) {
    console.error("Firebase test error:", err);
    if (err?.message?.includes('permission') || err?.code?.includes('permission')) {
      return { 
        success: false, 
        message: '🔒 Firestore Security Rules Restriction: Go to Firebase Console -> Firestore Database -> Rules tab, and set: "allow read, write: if true;" to grant access.' 
      };
    }
    return { success: false, message: err.message || 'Failed to connect to Firebase. Check API Key and Firestore rules.' };
  }
};

export const saveRecordToFirestore = async (collectionName: string, id: string, data: any) => {
  if (!dbInstance) return;
  try {
    await setDoc(doc(dbInstance, collectionName, id), {
      ...data,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.warn(`Firestore save error on ${collectionName}/${id}:`, err);
  }
};

export const deleteRecordFromFirestore = async (collectionName: string, id: string) => {
  if (!dbInstance) return;
  try {
    await deleteDoc(doc(dbInstance, collectionName, id));
  } catch (err) {
    console.warn(`Firestore delete error on ${collectionName}/${id}:`, err);
  }
};

export const clearAllFirestoreCollections = async () => {
  if (!dbInstance) return;
  const db = dbInstance;
  const collectionsToClear = ['items', 'transactions', 'wholesalers', 'invoices', 'accountTxns', 'suppliers', 'categories'];
  for (const colName of collectionsToClear) {
    try {
      const snapshot = await getDocs(collection(db, colName));
      const deletePromises = snapshot.docs.map(docSnap => deleteDoc(doc(db, colName, docSnap.id)));
      await Promise.all(deletePromises);
    } catch (err) {
      console.warn(`Error clearing Firestore collection ${colName}:`, err);
    }
  }
};

export const listenToCollection = (
  collectionName: string, 
  onData: (data: any[]) => void
) => {
  if (!dbInstance) return () => {};
  try {
    const colRef = collection(dbInstance, collectionName);
    return onSnapshot(colRef, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach(docSnap => {
        list.push({ ...docSnap.data(), id: docSnap.id });
      });
      onData(list);
    }, (error) => {
      console.warn(`Snapshot error on ${collectionName}:`, error);
    });
  } catch (err) {
    console.warn(`Error setting up listener for ${collectionName}:`, err);
    return () => {};
  }
};

export const listenToDocument = (
  collectionName: string, 
  docId: string, 
  onData: (data: any) => void
) => {
  if (!dbInstance) return () => {};
  try {
    const docRef = doc(dbInstance, collectionName, docId);
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        onData(docSnap.data());
      }
    }, (error) => {
      console.warn(`Snapshot error on doc ${collectionName}/${docId}:`, error);
    });
  } catch (err) {
    console.warn(`Error setting up listener for doc ${collectionName}/${docId}:`, err);
    return () => {};
  }
};

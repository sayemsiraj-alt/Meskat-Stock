export interface StockItem {
  id: string;
  name: string;
  category: string;
  sku: string;
  batchNo: string;
  quantity: number;
  unit: string;
  price: number;
  costPrice: number;
  supplier: string;
  expiryDate: string;
  reorderThreshold: number;
  location: string;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock' | 'Expiring Soon';
}

export interface StockTransaction {
  id: string;
  itemId: string;
  itemName: string;
  type: 'IN' | 'OUT' | 'RETURN' | 'ADJUSTMENT';
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  date: string;
  user: string;
  reference: string;
  notes: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  activeItems: number;
  status: 'Active' | 'Inactive';
}

export interface Category {
  id: string;
  name: string;
  description: string;
  count: number;
}

export interface RolePermissions {
  canManageInventory: boolean; // Add, edit, delete inventory items
  canManageTransactions: boolean; // Log Stock IN, OUT, RETURN
  canManageRetailPOS: boolean; // Process Retail Counter POS Sales
  canManageWholesale: boolean; // Create & Edit Wholesale Chalans
  canManageAccounts: boolean; // View Cash Ledger & Collect Dues
  canViewReports: boolean; // View & Export Executive Reports
  canManageSuppliersCategories: boolean; // Add/Edit Suppliers & Categories
  canManageSettingsUsers: boolean; // Manage Settings, Users & Firebase
}

export type RolePermissionMap = {
  admin: RolePermissions;
  manager: RolePermissions;
  staff: RolePermissions;
};

export const defaultRolePermissions: RolePermissionMap = {
  admin: {
    canManageInventory: true,
    canManageTransactions: true,
    canManageRetailPOS: true,
    canManageWholesale: true,
    canManageAccounts: true,
    canViewReports: true,
    canManageSuppliersCategories: true,
    canManageSettingsUsers: true,
  },
  manager: {
    canManageInventory: true,
    canManageTransactions: true,
    canManageRetailPOS: true,
    canManageWholesale: true,
    canManageAccounts: true,
    canViewReports: true,
    canManageSuppliersCategories: true,
    canManageSettingsUsers: false,
  },
  staff: {
    canManageInventory: false,
    canManageTransactions: true,
    canManageRetailPOS: true,
    canManageWholesale: false,
    canManageAccounts: false,
    canViewReports: false,
    canManageSuppliersCategories: false,
    canManageSettingsUsers: false,
  }
};

import { ThemeId } from '../utils/themeConfig';

export interface SystemSettings {
  storeName: string;
  brandName: string;
  brandShortName: string;
  logoUrl?: string;
  activeTheme?: ThemeId;
  currency: string;
  taxPercentage: number;
  defaultLowStockThreshold: number;
  emailAlerts: boolean;
  autoBatchNumbering: boolean;
  address: string;
  phone: string;
  themeMode: 'light' | 'dark';
  // Firebase Live Sync Properties
  firebaseApiKey?: string;
  firebaseAuthDomain?: string;
  firebaseProjectId?: string;
  firebaseStorageBucket?: string;
  firebaseMessagingSenderId?: string;
  firebaseAppId?: string;
  firebaseConnected?: boolean;
  firebaseLastSync?: string;
  // Dynamic Role Permissions
  rolePermissions?: RolePermissionMap;
}

export const initialSettings: SystemSettings = {
  storeName: 'Dear Health Care Ltd.',
  brandName: 'Dear Health Care',
  brandShortName: 'Dear',
  logoUrl: '',
  activeTheme: 'emerald-enterprise',
  currency: '৳ (BDT)',
  taxPercentage: 15,
  defaultLowStockThreshold: 30,
  emailAlerts: true,
  autoBatchNumbering: true,
  address: 'Mirpur-10, Dhaka, Bangladesh',
  phone: '+880 1712-345678',
  themeMode: 'light',
  firebaseApiKey: 'AIzaSyDj4cPq7d4SgoFZCOqIZwqn7bwHgTDUMmw',
  firebaseAuthDomain: 'meskat-stock-managment.firebaseapp.com',
  firebaseProjectId: 'meskat-stock-managment',
  firebaseStorageBucket: 'meskat-stock-managment.firebasestorage.app',
  firebaseMessagingSenderId: '902624685278',
  firebaseAppId: '1:902624685278:web:3d7bd7b638c5317b87664f',
  firebaseConnected: true,
  firebaseLastSync: new Date().toISOString(),
  rolePermissions: defaultRolePermissions
};

export const initialCategories: Category[] = [];

export const initialSuppliers: Supplier[] = [];

export const initialStockItems: StockItem[] = [];

export const initialTransactions: StockTransaction[] = [];

export interface SystemUser {
  id: string;
  userId: string;
  passwordHash: string;
  name: string;
  role: 'admin' | 'manager' | 'staff';
  status: 'Active' | 'Inactive';
  profilePicUrl?: string;
}

export const initialUsers: SystemUser[] = [
  { id: 'USR-1', userId: 'admin', passwordHash: 'dearhealth2026', name: 'Admin (Kamrul)', role: 'admin', status: 'Active' },
  { id: 'USR-2', userId: 'manager', passwordHash: 'manager2026', name: 'Manager (Farjana)', role: 'manager', status: 'Active' },
  { id: 'USR-3', userId: 'staff', passwordHash: 'staff2026', name: 'Staff (Rahim)', role: 'staff', status: 'Active' }
];

export interface Wholesaler {
  id: string;
  name: string;
  phone: string;
  address: string;
  totalDue: number;
}

export interface InvoiceItem {
  itemId: string;
  itemName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  chalanNo: string;
  wholesalerId: string;
  wholesalerName: string;
  customerPhone?: string;
  saleType?: 'Retail' | 'Wholesale';
  items: InvoiceItem[];
  subTotal?: number;
  discount?: number;
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod?: 'Cash' | 'bKash' | 'Nagad' | 'Card';
  date: string;
  status: 'Paid' | 'Partial' | 'Unpaid';
}

export interface AccountTxn {
  id: string;
  date: string;
  type: 'IN' | 'OUT';
  amount: number;
  reference: string;
  description: string;
}

export interface Expense {
  id: string;
  category: string;
  amount: number;
  date: string;
  description: string;
  user: string;
}

export interface PurchaseOrderItem {
  itemId: string;
  itemName: string;
  quantity: number;
  costPrice: number;
  total: number;
}

export interface PurchaseOrder {
  id: string;
  poNo: string;
  supplierName: string;
  supplierPhone?: string;
  items: PurchaseOrderItem[];
  totalAmount: number;
  date: string;
  status: 'Draft' | 'Sent' | 'Received' | 'Cancelled';
  notes?: string;
}

export interface DamagedStock {
  id: string;
  itemId: string;
  itemName: string;
  sku: string;
  quantity: number;
  unit: string;
  reason: 'Expired' | 'Damaged' | 'Broken' | 'Lost';
  costValue: number;
  date: string;
  user: string;
  notes?: string;
}

export interface LoyaltyCustomer {
  id: string;
  name: string;
  phone: string;
  points: number;
  totalSpent: number;
  lastVisit: string;
}

export const initialWholesalers: Wholesaler[] = [];
export const initialInvoices: Invoice[] = [];
export const initialAccountTxns: AccountTxn[] = [];
export const initialExpenses: Expense[] = [];
export const initialPurchaseOrders: PurchaseOrder[] = [];
export const initialDamagedStock: DamagedStock[] = [];
export const initialLoyaltyCustomers: LoyaltyCustomer[] = [];

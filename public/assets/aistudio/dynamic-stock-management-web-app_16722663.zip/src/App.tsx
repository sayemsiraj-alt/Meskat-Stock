import { useState, useEffect } from 'react';
import { initFirebase, saveRecordToFirestore, deleteRecordFromFirestore, listenToCollection, listenToDocument, clearAllFirestoreCollections } from './utils/firebaseService';
import { 
  initialStockItems, 
  initialTransactions, 
  initialCategories, 
  initialSuppliers, 
  initialSettings,
  initialUsers,
  initialWholesalers,
  initialInvoices,
  initialAccountTxns,
  initialExpenses,
  initialPurchaseOrders,
  initialDamagedStock,
  defaultRolePermissions,
  StockItem,
  StockTransaction,
  Category,
  Supplier,
  SystemSettings,
  SystemUser,
  Wholesaler,
  Invoice,
  AccountTxn,
  Expense,
  PurchaseOrder,
  DamagedStock
} from './data/mockData';
import { LoginScreen } from './components/LoginScreen';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { InventoryView } from './components/InventoryView';
import { StockTransactionsView } from './components/StockTransactionsView';
import { ReportsView } from './components/ReportsView';
import { SuppliersView } from './components/SuppliersView';
import { CategoriesView } from './components/CategoriesView';
import { SettingsView } from './components/SettingsView';
import { WholesalersView } from './components/WholesalersView';
import { SalesInvoiceView } from './components/SalesInvoiceView';
import { RetailPosView } from './components/RetailPosView';
import { AccountsView } from './components/AccountsView';
import { ExpensesView } from './components/ExpensesView';
import { PurchaseOrdersView } from './components/PurchaseOrdersView';
import { getThemeConfig } from './utils/themeConfig';
import { ExpiryDamageView } from './components/ExpiryDamageView';
import { AiChatbot } from './components/AiChatbot';
import { getLocalYYYYMMDD } from './utils/dateUtils';

export default function App() {
  // Authentication state (Defaults to FALSE on any new computer/browser unless remembered)
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    const permActive = localStorage.getItem('dh_session_active');
    const tempActive = sessionStorage.getItem('dh_session_active');
    return permActive === 'true' || tempActive === 'true';
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    return localStorage.getItem('dh_current_user_id') || sessionStorage.getItem('dh_current_user_id') || '';
  });

  const [userRole, setUserRole] = useState<'admin' | 'manager' | 'staff'>(() => {
    return (localStorage.getItem('dh_user_role') as any) || (sessionStorage.getItem('dh_user_role') as any) || 'admin';
  });

  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem('dh_user_name') || sessionStorage.getItem('dh_user_name') || 'Admin (Kamrul)';
  });

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [systemDate, setSystemDate] = useState<string>(getLocalYYYYMMDD());

  // LocalStorage Helpers
  const loadLocal = <T,>(key: string, fallback: T): T => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : fallback;
    } catch (e) {
      return fallback;
    }
  };

  // Application Data States (Persisted in LocalStorage & Firebase Cloud)
  const [items, setItems] = useState<StockItem[]>(() => loadLocal('dh_items', initialStockItems));
  const [transactions, setTransactions] = useState<StockTransaction[]>(() => loadLocal('dh_txns', initialTransactions));
  const [categories, setCategories] = useState<Category[]>(() => loadLocal('dh_categories', initialCategories));
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => loadLocal('dh_suppliers', initialSuppliers));
  const [settings, setSettings] = useState<SystemSettings>(() => {
    const localSettings = loadLocal('dh_settings', initialSettings);
    if (!localSettings.firebaseApiKey && initialSettings.firebaseApiKey) {
      return { ...localSettings, ...initialSettings, firebaseConnected: true };
    }
    return localSettings;
  });
  const [users, setUsers] = useState<SystemUser[]>(() => loadLocal('dh_users', initialUsers));
  
  const [wholesalers, setWholesalers] = useState<Wholesaler[]>(() => loadLocal('dh_wholesalers', initialWholesalers));
  const [invoices, setInvoices] = useState<Invoice[]>(() => loadLocal('dh_invoices', initialInvoices));
  const [accountTxns, setAccountTxns] = useState<AccountTxn[]>(() => loadLocal('dh_accountTxns', initialAccountTxns));
  const [expenses, setExpenses] = useState<Expense[]>(() => loadLocal('dh_expenses', initialExpenses));
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => loadLocal('dh_purchase_orders', initialPurchaseOrders));
  const [damagedStockList, setDamagedStockList] = useState<DamagedStock[]>(() => loadLocal('dh_damaged_stock', initialDamagedStock));

  // Sync to LocalStorage
  useEffect(() => { localStorage.setItem('dh_items', JSON.stringify(items)); }, [items]);
  useEffect(() => { localStorage.setItem('dh_txns', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('dh_categories', JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem('dh_suppliers', JSON.stringify(suppliers)); }, [suppliers]);
  useEffect(() => { localStorage.setItem('dh_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('dh_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('dh_wholesalers', JSON.stringify(wholesalers)); }, [wholesalers]);
  useEffect(() => { localStorage.setItem('dh_invoices', JSON.stringify(invoices)); }, [invoices]);
  useEffect(() => { localStorage.setItem('dh_accountTxns', JSON.stringify(accountTxns)); }, [accountTxns]);
  useEffect(() => { localStorage.setItem('dh_expenses', JSON.stringify(expenses)); }, [expenses]);
  useEffect(() => { localStorage.setItem('dh_purchase_orders', JSON.stringify(purchaseOrders)); }, [purchaseOrders]);
  useEffect(() => { localStorage.setItem('dh_damaged_stock', JSON.stringify(damagedStockList)); }, [damagedStockList]);

  // Dynamic Browser Tab Title Sync
  useEffect(() => {
    const titleName = settings.brandName || settings.storeName || 'Stock Management System';
    document.title = `${titleName} - Stock Management System`;
  }, [settings.brandName, settings.storeName]);

  // --- FIREBASE LIVE CLOUD SYNC & LISTENERS ---
  useEffect(() => {
    if (!settings.firebaseConnected || !settings.firebaseApiKey || !settings.firebaseProjectId) return;

    const db = initFirebase(settings);
    if (!db) return;

    // Set up Live Cloud Firestore Listeners for ALL collections and settings
    const unsubItems = listenToCollection('items', (remoteItems) => { setItems(remoteItems || []); });
    const unsubTxns = listenToCollection('transactions', (remoteTxns) => { setTransactions(remoteTxns || []); });
    const unsubWholesalers = listenToCollection('wholesalers', (remote) => { setWholesalers(remote || []); });
    const unsubInvoices = listenToCollection('invoices', (remote) => { setInvoices(remote || []); });
    const unsubAccountTxns = listenToCollection('accountTxns', (remote) => { setAccountTxns(remote || []); });
    const unsubExpenses = listenToCollection('expenses', (remoteExp) => { setExpenses(remoteExp || []); });
    const unsubPOs = listenToCollection('purchase_orders', (remotePO) => { setPurchaseOrders(remotePO || []); });
    const unsubDamaged = listenToCollection('damaged_stock', (remoteDmg) => { setDamagedStockList(remoteDmg || []); });
    const unsubSuppliers = listenToCollection('suppliers', (remote) => { setSuppliers(remote || []); });
    const unsubCategories = listenToCollection('categories', (remote) => { setCategories(remote || []); });
    const unsubUsers = listenToCollection('users', (remoteUsers) => { if (remoteUsers?.length) setUsers(remoteUsers); });
    const unsubSettings = listenToDocument('settings', 'config', (remoteSettings) => {
      if (remoteSettings && remoteSettings.brandName) {
        setSettings(prev => ({ ...prev, ...remoteSettings }));
      }
    });

    return () => {
      unsubItems();
      unsubTxns();
      unsubWholesalers();
      unsubInvoices();
      unsubAccountTxns();
      unsubExpenses();
      unsubPOs();
      unsubDamaged();
      unsubSuppliers();
      unsubCategories();
      unsubUsers();
      unsubSettings();
    };
  }, [settings.firebaseConnected, settings.firebaseApiKey, settings.firebaseProjectId]);

  const handleLogin = (user: SystemUser, rememberMe: boolean) => {
    setUserRole(user.role);
    setUserName(user.name);
    setCurrentUserId(user.userId);
    setIsLoggedIn(true);
    setCurrentTab('dashboard');

    const storage = rememberMe ? localStorage : sessionStorage;
    storage.setItem('dh_session_active', 'true');
    storage.setItem('dh_user_role', user.role);
    storage.setItem('dh_user_name', user.name);
    storage.setItem('dh_current_user_id', user.userId);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('dh_session_active');
    localStorage.removeItem('dh_user_role');
    localStorage.removeItem('dh_user_name');
    localStorage.removeItem('dh_current_user_id');

    sessionStorage.removeItem('dh_session_active');
    sessionStorage.removeItem('dh_user_role');
    sessionStorage.removeItem('dh_user_name');
    sessionStorage.removeItem('dh_current_user_id');
  };

  // --- AUTOMATIC STOCK MANAGEMENT HANDLERS ---
  const handleAddItem = (newItem: Omit<StockItem, 'id' | 'status'>) => {
    const id = `ITEM-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const status = newItem.quantity === 0 ? 'Out of Stock' : (newItem.quantity <= newItem.reorderThreshold ? 'Low Stock' : 'In Stock');
    const completeItem: StockItem = {
      ...newItem,
      id,
      status
    };
    setItems(prev => [completeItem, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('items', completeItem.id, completeItem);

    // Also update category count
    setCategories(prev => prev.map(c => c.name === newItem.category ? { ...c, count: c.count + 1 } : c));
  };

  const handleUpdateItem = (updatedItem: StockItem) => {
    setItems(prev => prev.map(i => i.id === updatedItem.id ? updatedItem : i));
    if (settings.firebaseConnected) saveRecordToFirestore('items', updatedItem.id, updatedItem);
  };

  const handleDeleteItem = (id: string) => {
    if (confirm('Are you sure you want to delete this inventory item?')) {
      setItems(prev => prev.filter(i => i.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('items', id);
    }
  };

  // Adding a transaction automatically adjusts stock item quantities
  const handleAddTransaction = (txn: Omit<StockTransaction, 'id' | 'totalPrice'>) => {
    const id = `TXN-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const totalPrice = txn.quantity * txn.unitPrice;
    const completeTxn: StockTransaction = {
      ...txn,
      id,
      totalPrice
    };

    // Update transactions list
    setTransactions(prev => [completeTxn, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('transactions', completeTxn.id, completeTxn);

    // Automatically recalculate item quantity
    setItems(prev => prev.map(item => {
      if (item.id === txn.itemId) {
        let newQty = item.quantity;
        if (txn.type === 'IN' || txn.type === 'RETURN') {
          newQty += txn.quantity;
        } else if (txn.type === 'OUT') {
          newQty = Math.max(0, newQty - txn.quantity);
        }
        const updatedStatus: StockItem['status'] = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
        const updatedItem: StockItem = {
          ...item,
          quantity: newQty,
          status: updatedStatus
        };
        if (settings.firebaseConnected) saveRecordToFirestore('items', updatedItem.id, updatedItem);
        return updatedItem;
      }
      return item;
    }));
  };

  const handleAddSupplier = (newSup: Omit<Supplier, 'id' | 'activeItems' | 'status'>) => {
    const id = `SUP-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const completeSup: Supplier = {
      ...newSup,
      id,
      activeItems: 0,
      status: 'Active'
    };
    setSuppliers(prev => [...prev, completeSup]);
    if (settings.firebaseConnected) saveRecordToFirestore('suppliers', completeSup.id, completeSup);
  };

  const handleAddCategory = (newCat: Omit<Category, 'id' | 'count'>) => {
    const id = `CAT-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const completeCat: Category = {
      ...newCat,
      id,
      count: 0
    };
    setCategories(prev => [...prev, completeCat]);
    if (settings.firebaseConnected) saveRecordToFirestore('categories', completeCat.id, completeCat);
  };

  const handleUpdateCategory = (updatedCat: Category, oldName: string) => {
    setCategories(prev => prev.map(c => c.id === updatedCat.id ? updatedCat : c));
    if (settings.firebaseConnected) saveRecordToFirestore('categories', updatedCat.id, updatedCat);
    if (updatedCat.name !== oldName) {
      setItems(prev => prev.map(item => item.category === oldName ? { ...item, category: updatedCat.name } : item));
    }
  };

  const handleDeleteCategory = (id: string) => {
    if (confirm('Are you sure you want to delete this category?')) {
      setCategories(prev => prev.filter(c => c.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('categories', id);
    }
  };

  const handleUpdateSupplier = (updatedSup: Supplier, oldName: string) => {
    setSuppliers(prev => prev.map(s => s.id === updatedSup.id ? updatedSup : s));
    if (settings.firebaseConnected) saveRecordToFirestore('suppliers', updatedSup.id, updatedSup);
    if (updatedSup.name !== oldName) {
      setItems(prev => prev.map(item => item.supplier === oldName ? { ...item, supplier: updatedSup.name } : item));
    }
  };

  const handleDeleteSupplier = (id: string) => {
    if (confirm('Are you sure you want to delete this supplier?')) {
      setSuppliers(prev => prev.filter(s => s.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('suppliers', id);
    }
  };

  const handleUpdateTransaction = (updatedTxn: StockTransaction) => {
    const oldTxn = transactions.find(t => t.id === updatedTxn.id);
    if (!oldTxn) return;
    
    // Reverse old transaction effect
    let itemEffects: Record<string, number> = { [oldTxn.itemId]: 0 };
    if (oldTxn.type === 'IN' || oldTxn.type === 'RETURN') itemEffects[oldTxn.itemId] -= oldTxn.quantity;
    if (oldTxn.type === 'OUT') itemEffects[oldTxn.itemId] += oldTxn.quantity;

    // Apply new transaction effect
    if (updatedTxn.type === 'IN' || updatedTxn.type === 'RETURN') itemEffects[updatedTxn.itemId] = (itemEffects[updatedTxn.itemId] || 0) + updatedTxn.quantity;
    if (updatedTxn.type === 'OUT') itemEffects[updatedTxn.itemId] = (itemEffects[updatedTxn.itemId] || 0) - updatedTxn.quantity;

    setTransactions(prev => prev.map(t => t.id === updatedTxn.id ? { ...updatedTxn, totalPrice: updatedTxn.quantity * updatedTxn.unitPrice } : t));

    // Update items quantities
    setItems(prev => prev.map(item => {
      if (itemEffects[item.id] !== undefined && itemEffects[item.id] !== 0) {
        const newQty = Math.max(0, item.quantity + itemEffects[item.id]);
        const updatedStatus = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
        return { ...item, quantity: newQty, status: updatedStatus };
      }
      return item;
    }));
  };

  const handleDeleteTransaction = (id: string) => {
    if (!confirm('Are you sure you want to delete this transaction record? This will affect stock quantities.')) return;
    
    const oldTxn = transactions.find(t => t.id === id);
    if (!oldTxn) return;

    setTransactions(prev => prev.filter(t => t.id !== id));
    if (settings.firebaseConnected) deleteRecordFromFirestore('transactions', id);
    
    // Reverse transaction effect
    setItems(prev => prev.map(item => {
      if (item.id === oldTxn.itemId) {
        let newQty = item.quantity;
        if (oldTxn.type === 'IN' || oldTxn.type === 'RETURN') newQty = Math.max(0, newQty - oldTxn.quantity);
        if (oldTxn.type === 'OUT') newQty += oldTxn.quantity;
        const updatedStatus: StockItem['status'] = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
        const updatedItem: StockItem = { ...item, quantity: newQty, status: updatedStatus };
        if (settings.firebaseConnected) saveRecordToFirestore('items', updatedItem.id, updatedItem);
        return updatedItem;
      }
      return item;
    }));
  };

  const handleAddWholesaler = (w: Omit<Wholesaler, 'id' | 'totalDue'>) => {
    const id = `CUST-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const newW = { ...w, id, totalDue: 0 };
    setWholesalers(prev => [...prev, newW]);
    if (settings.firebaseConnected) saveRecordToFirestore('wholesalers', id, newW);
  };

  const handleUpdateWholesaler = (w: Wholesaler) => {
    setWholesalers(prev => prev.map(x => x.id === w.id ? w : x));
    if (settings.firebaseConnected) saveRecordToFirestore('wholesalers', w.id, w);
  };

  const handleDeleteWholesaler = (id: string) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      setWholesalers(prev => prev.filter(w => w.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('wholesalers', id);
    }
  };

  const handleUpdateWholesalerDue = (id: string, amount: number) => {
    setWholesalers(prev => prev.map(w => {
      if (w.id === id) {
        const updatedW = { ...w, totalDue: w.totalDue + amount };
        if (settings.firebaseConnected) saveRecordToFirestore('wholesalers', id, updatedW);
        return updatedW;
      }
      return w;
    }));
  };

  const handleAddAccountTxn = (txn: Omit<AccountTxn, 'id'>) => {
    const id = `ACT-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const newTxn = { ...txn, id };
    setAccountTxns(prev => [newTxn, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('accountTxns', id, newTxn);
  };

  const handleAddInvoice = (inv: Omit<Invoice, 'id'>) => {
    const id = `INV-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const newInv = { ...inv, id };
    
    // Update due
    if (inv.dueAmount > 0) {
      handleUpdateWholesalerDue(inv.wholesalerId, inv.dueAmount);
    }
    
    // Save invoice
    setInvoices(prev => [newInv, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('invoices', id, newInv);

    // Handle initial payment received at checkout
    if (inv.paidAmount > 0) {
      handleAddAccountTxn({
        date: inv.date,
        type: 'IN',
        amount: inv.paidAmount,
        reference: inv.chalanNo,
        description: `Advance/Cash paid for Sale ${inv.chalanNo}`
      });
    }

    // Deduct stock for each item sold & Log OUT transaction
    inv.items.forEach(soldItem => {
      handleAddTransaction({
        itemId: soldItem.itemId,
        itemName: soldItem.itemName,
        type: 'OUT',
        quantity: soldItem.quantity,
        unitPrice: soldItem.unitPrice,
        date: inv.date,
        user: userName,
        reference: inv.chalanNo,
        notes: `Wholesale Sale`
      });
    });
  };

  const handleUpdateInvoice = (updatedInv: Invoice) => {
    const oldInv = invoices.find(i => i.id === updatedInv.id);
    if (!oldInv) return;

    // 1. Reverse old due and apply new due
    if (oldInv.dueAmount !== 0) {
      handleUpdateWholesalerDue(oldInv.wholesalerId, -oldInv.dueAmount);
    }
    if (updatedInv.dueAmount !== 0) {
      handleUpdateWholesalerDue(updatedInv.wholesalerId, updatedInv.dueAmount);
    }

    // 2. Revert old stock items and apply new stock items
    setItems(prev => {
      let updatedItems = [...prev];
      // Restore old items
      oldInv.items.forEach(oldItem => {
        updatedItems = updatedItems.map(item => {
          if (item.id === oldItem.itemId) {
            const newQty = item.quantity + oldItem.quantity;
            const updatedStatus = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
            return { ...item, quantity: newQty, status: updatedStatus };
          }
          return item;
        });
      });
      // Deduct new items
      updatedInv.items.forEach(newItem => {
        updatedItems = updatedItems.map(item => {
          if (item.id === newItem.itemId) {
            const newQty = Math.max(0, item.quantity - newItem.quantity);
            const updatedStatus = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
            return { ...item, quantity: newQty, status: updatedStatus };
          }
          return item;
        });
      });
      return updatedItems;
    });

    // 3. Update Invoice in state
    setInvoices(prev => prev.map(inv => inv.id === updatedInv.id ? updatedInv : inv));
    if (settings.firebaseConnected) saveRecordToFirestore('invoices', updatedInv.id, updatedInv);

    // 4. Update account transaction ledger for cash advance
    if (oldInv.paidAmount !== updatedInv.paidAmount) {
      setAccountTxns(prev => {
        const existingTxn = prev.find(t => t.reference === oldInv.chalanNo);
        if (existingTxn) {
          if (updatedInv.paidAmount <= 0) {
            return prev.filter(t => t.reference !== oldInv.chalanNo);
          } else {
            return prev.map(t => t.reference === oldInv.chalanNo ? { ...t, amount: updatedInv.paidAmount } : t);
          }
        } else if (updatedInv.paidAmount > 0) {
          return [{
            id: `ACT-${prev.length + 8001}`,
            date: updatedInv.date,
            type: 'IN',
            amount: updatedInv.paidAmount,
            reference: updatedInv.chalanNo,
            description: `Advance/Cash paid for Sale ${updatedInv.chalanNo}`
          }, ...prev];
        }
        return prev;
      });
    }
  };

  const handleDeleteInvoice = (id: string) => {
    const oldInv = invoices.find(i => i.id === id);
    if (!oldInv) return;

    if (!confirm(`Are you sure you want to delete Chalan ${oldInv.chalanNo}? Stock levels and dues will be restored.`)) return;

    // 1. Reverse due
    if (oldInv.dueAmount > 0) {
      handleUpdateWholesalerDue(oldInv.wholesalerId, -oldInv.dueAmount);
    }

    // 2. Restore stock items
    setItems(prev => {
      let updatedItems = [...prev];
      oldInv.items.forEach(oldItem => {
        updatedItems = updatedItems.map(item => {
          if (item.id === oldItem.itemId) {
            const newQty = item.quantity + oldItem.quantity;
            const updatedStatus = newQty === 0 ? 'Out of Stock' : (newQty <= item.reorderThreshold ? 'Low Stock' : 'In Stock');
            return { ...item, quantity: newQty, status: updatedStatus };
          }
          return item;
        });
      });
      return updatedItems;
    });

    // 3. Remove cash ledger entry if any
    setAccountTxns(prev => prev.filter(t => t.reference !== oldInv.chalanNo));

    // 4. Remove invoice
    setInvoices(prev => prev.filter(inv => inv.id !== id));
    if (settings.firebaseConnected) deleteRecordFromFirestore('invoices', id);
  };

  // --- EXPENSE HANDLERS ---
  const handleAddExpense = (exp: Omit<Expense, 'id'>) => {
    const id = `EXP-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const newExp = { ...exp, id };
    setExpenses(prev => [newExp, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('expenses', id, newExp);

    // Auto log expense to cash ledger as CASH OUT
    handleAddAccountTxn({
      date: exp.date,
      type: 'OUT',
      amount: exp.amount,
      reference: id,
      description: `Expense: ${exp.category} - ${exp.description}`
    });
  };

  const handleUpdateExpense = (exp: Expense) => {
    setExpenses(prev => prev.map(x => x.id === exp.id ? exp : x));
    if (settings.firebaseConnected) saveRecordToFirestore('expenses', exp.id, exp);
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('Are you sure you want to delete this expense voucher?')) {
      setExpenses(prev => prev.filter(x => x.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('expenses', id);
    }
  };

  // --- PURCHASE ORDER HANDLERS ---
  const handleAddPO = (po: Omit<PurchaseOrder, 'id'>) => {
    const id = `PO-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const newPO = { ...po, id };
    setPurchaseOrders(prev => [newPO, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('purchase_orders', id, newPO);
  };

  const handleUpdatePO = (po: PurchaseOrder) => {
    setPurchaseOrders(prev => prev.map(x => x.id === po.id ? po : x));
    if (settings.firebaseConnected) saveRecordToFirestore('purchase_orders', po.id, po);
  };

  const handleDeletePO = (id: string) => {
    if (confirm('Are you sure you want to delete this Purchase Order?')) {
      setPurchaseOrders(prev => prev.filter(x => x.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('purchase_orders', id);
    }
  };

  const handleReceivePOItems = (po: PurchaseOrder) => {
    // Restock each product in the PO
    po.items.forEach(poItem => {
      handleAddTransaction({
        itemId: poItem.itemId,
        itemName: poItem.itemName,
        type: 'IN',
        quantity: poItem.quantity,
        unitPrice: poItem.costPrice,
        date: new Date().toISOString(),
        user: userName,
        reference: po.poNo,
        notes: `PO Received from ${po.supplierName}`
      });
    });

    // Mark PO status as Received
    const updatedPO: PurchaseOrder = { ...po, status: 'Received' };
    handleUpdatePO(updatedPO);
  };

  // --- DAMAGED / EXPIRED STOCK HANDLERS ---
  const handleAddDamagedStock = (dmg: Omit<DamagedStock, 'id'>) => {
    const id = `DMG-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
    const newDmg = { ...dmg, id };
    setDamagedStockList(prev => [newDmg, ...prev]);
    if (settings.firebaseConnected) saveRecordToFirestore('damaged_stock', id, newDmg);

    // Auto-deduct stock from inventory & log transaction
    handleAddTransaction({
      itemId: dmg.itemId,
      itemName: dmg.itemName,
      type: 'OUT',
      quantity: dmg.quantity,
      unitPrice: dmg.costValue / (dmg.quantity || 1),
      date: dmg.date,
      user: userName,
      reference: id,
      notes: `Write-Off: ${dmg.reason} (${dmg.notes || ''})`
    });
  };

  const handleDeleteDamagedStock = (id: string) => {
    if (confirm('Are you sure you want to delete this damaged stock record?')) {
      setDamagedStockList(prev => prev.filter(x => x.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('damaged_stock', id);
    }
  };

  const handleUpdateSettings = (newSettings: SystemSettings) => {
    setSettings(newSettings);
    if (newSettings.firebaseConnected) saveRecordToFirestore('settings', 'config', newSettings);
  };

  const handleResetAllData = async () => {
    // 1. Wipe local state
    setItems([]);
    setTransactions([]);
    setWholesalers([]);
    setInvoices([]);
    setAccountTxns([]);
    setExpenses([]);
    setPurchaseOrders([]);
    setDamagedStockList([]);
    setSuppliers([]);
    setCategories([]);

    // 2. Clear LocalStorage
    localStorage.removeItem('dh_items');
    localStorage.removeItem('dh_txns');
    localStorage.removeItem('dh_wholesalers');
    localStorage.removeItem('dh_invoices');
    localStorage.removeItem('dh_accountTxns');
    localStorage.removeItem('dh_expenses');
    localStorage.removeItem('dh_purchase_orders');
    localStorage.removeItem('dh_damaged_stock');
    localStorage.removeItem('dh_suppliers');
    localStorage.removeItem('dh_categories');

    // 3. Clear Firebase Firestore collections if connected
    if (settings.firebaseConnected) {
      await clearAllFirestoreCollections();
    }
  };

  const handleExportBackupJSON = () => {
    const backupObj = {
      appName: settings.brandName || settings.storeName || 'Stock Management',
      exportDate: new Date().toISOString(),
      version: '2.6.0',
      data: {
        items,
        transactions,
        categories,
        suppliers,
        wholesalers,
        invoices,
        accountTxns,
        expenses,
        purchaseOrders,
        damagedStockList,
        users,
        settings
      }
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupObj, null, 2));
    const downloadAnchor = document.createElement('a');
    const dateTag = getLocalYYYYMMDD();
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${(settings.brandName || 'StockApp').replace(/\s+/g, '_')}_Backup_${dateTag}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportBackupCSV = () => {
    if (items.length === 0) {
      alert('No inventory items available to export.');
      return;
    }
    const headers = ['ID', 'Name', 'Category', 'SKU', 'BatchNo', 'Quantity', 'Unit', 'Price', 'CostPrice', 'Supplier', 'ExpiryDate', 'Location', 'Status'];
    const rows = items.map(i => [
      i.id,
      `"${i.name.replace(/"/g, '""')}"`,
      `"${i.category.replace(/"/g, '""')}"`,
      i.sku,
      i.batchNo,
      i.quantity,
      i.unit,
      i.price,
      i.costPrice,
      `"${i.supplier.replace(/"/g, '""')}"`,
      i.expiryDate,
      `"${i.location.replace(/"/g, '""')}"`,
      i.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", encodeURI(csvContent));
    downloadAnchor.setAttribute("download", `${(settings.brandName || 'StockApp').replace(/\s+/g, '_')}_Products_${getLocalYYYYMMDD()}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportBackupJSON = async (backupPayload: any): Promise<{ success: boolean; message: string }> => {
    try {
      const data = backupPayload?.data || backupPayload;
      if (!data) return { success: false, message: 'Invalid backup file structure.' };

      let restoredProductsCount = 0;

      if (Array.isArray(data.items)) {
        setItems(data.items);
        restoredProductsCount = data.items.length;
        if (settings.firebaseConnected) {
          data.items.forEach((item: any) => saveRecordToFirestore('items', item.id, item));
        }
      }
      if (Array.isArray(data.transactions)) {
        setTransactions(data.transactions);
        if (settings.firebaseConnected) {
          data.transactions.forEach((txn: any) => saveRecordToFirestore('transactions', txn.id, txn));
        }
      }
      if (Array.isArray(data.categories)) {
        setCategories(data.categories);
        if (settings.firebaseConnected) {
          data.categories.forEach((cat: any) => saveRecordToFirestore('categories', cat.id, cat));
        }
      }
      if (Array.isArray(data.suppliers)) {
        setSuppliers(data.suppliers);
        if (settings.firebaseConnected) {
          data.suppliers.forEach((sup: any) => saveRecordToFirestore('suppliers', sup.id, sup));
        }
      }
      if (Array.isArray(data.wholesalers)) {
        setWholesalers(data.wholesalers);
        if (settings.firebaseConnected) {
          data.wholesalers.forEach((w: any) => saveRecordToFirestore('wholesalers', w.id, w));
        }
      }
      if (Array.isArray(data.invoices)) {
        setInvoices(data.invoices);
        if (settings.firebaseConnected) {
          data.invoices.forEach((inv: any) => saveRecordToFirestore('invoices', inv.id, inv));
        }
      }
      if (Array.isArray(data.accountTxns)) {
        setAccountTxns(data.accountTxns);
        if (settings.firebaseConnected) {
          data.accountTxns.forEach((act: any) => saveRecordToFirestore('accountTxns', act.id, act));
        }
      }
      if (Array.isArray(data.expenses)) {
        setExpenses(data.expenses);
        if (settings.firebaseConnected) {
          data.expenses.forEach((exp: any) => saveRecordToFirestore('expenses', exp.id, exp));
        }
      }
      if (Array.isArray(data.purchaseOrders)) {
        setPurchaseOrders(data.purchaseOrders);
        if (settings.firebaseConnected) {
          data.purchaseOrders.forEach((po: any) => saveRecordToFirestore('purchase_orders', po.id, po));
        }
      }
      if (Array.isArray(data.damagedStockList)) {
        setDamagedStockList(data.damagedStockList);
        if (settings.firebaseConnected) {
          data.damagedStockList.forEach((dmg: any) => saveRecordToFirestore('damaged_stock', dmg.id, dmg));
        }
      }
      if (Array.isArray(data.users) && data.users.length) {
        setUsers(data.users);
        if (settings.firebaseConnected) {
          data.users.forEach((usr: any) => saveRecordToFirestore('users', usr.id, usr));
        }
      }
      if (data.settings && typeof data.settings === 'object') {
        setSettings(prev => ({ ...prev, ...data.settings }));
        if (settings.firebaseConnected) {
          saveRecordToFirestore('settings', 'config', data.settings);
        }
      }

      return { 
        success: true, 
        message: `Backup restored successfully! Restored ${restoredProductsCount} products, chalans, and ledgers. Synced to Cloud & LocalStorage.` 
      };
    } catch (err: any) {
      return { success: false, message: `Failed to import backup: ${err.message || 'Unknown error'}` };
    }
  };

  const currentRolePermissions = (settings.rolePermissions || defaultRolePermissions)[userRole];

  const handleAddUser = (newUser: Omit<SystemUser, 'id'>) => {
    const id = `USR-${users.length + 1}`;
    const completeUser = { ...newUser, id };
    setUsers(prev => [...prev, completeUser]);
    if (settings.firebaseConnected) saveRecordToFirestore('users', id, completeUser);
  };

  const handleUpdateUser = (updatedUser: SystemUser) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (settings.firebaseConnected) saveRecordToFirestore('users', updatedUser.id, updatedUser);
    
    // If updating currently logged in user, reflect changes in session
    if (userName === updatedUser.name || userRole === updatedUser.role) {
      setUserName(updatedUser.name);
      setUserRole(updatedUser.role);
    }
  };

  const handleDeleteUser = (id: string) => {
    const target = users.find(u => u.id === id);
    if (!target) return;
    if (target.role === 'admin' && users.filter(u => u.role === 'admin').length <= 1) {
      alert('At least one Admin user account must remain in the system.');
      return;
    }
    if (confirm(`Are you sure you want to delete user "${target.name}" (${target.userId})?`)) {
      setUsers(prev => prev.filter(u => u.id !== id));
      if (settings.firebaseConnected) deleteRecordFromFirestore('users', id);
    }
  };

  const currentUser = users.find(u => u.userId === currentUserId || u.name === userName || u.role === userRole) || users[0];

  // Calculate low stock items count for sidebar warning badge
  const lowStockCount = items.filter(i => i.quantity <= i.reorderThreshold).length;
  const activeThemeConfig = getThemeConfig(settings.activeTheme);

  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} users={users} settings={settings} />;
  }

  return (
    <div className={`flex h-[100dvh] w-full overflow-hidden ${activeThemeConfig.appBgClass} font-sans antialiased transition-colors duration-300`}>
      {/* Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onLogout={handleLogout}
        userName={userName}
        userRole={userRole}
        currentUser={currentUser}
        lowStockCount={lowStockCount}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        brandName={settings.brandName}
        brandShortName={settings.brandShortName}
        logoUrl={settings.logoUrl}
        permissions={currentRolePermissions}
        activeTheme={settings.activeTheme}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0 h-full overflow-hidden">
        <Header
          currentTab={currentTab}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          userName={userName}
          userRole={userRole}
          currentUser={currentUser}
          onUpdateProfile={handleUpdateUser}
          storeName={settings.storeName}
          brandName={settings.brandName}
          brandShortName={settings.brandShortName}
          logoUrl={settings.logoUrl}
          systemDate={systemDate}
          onSystemDateChange={setSystemDate}
          onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
          onLogout={handleLogout}
          onSelectTab={setCurrentTab}
          lowStockCount={lowStockCount}
          activeTheme={settings.activeTheme}
        />

        <main className="flex-1 overflow-y-auto relative">
          {currentTab === 'dashboard' && (
            <DashboardView
              items={items}
              transactions={transactions}
              invoices={invoices}
              wholesalers={wholesalers}
              accountTxns={accountTxns}
              expenses={expenses}
              damageStocks={damagedStockList}
              purchaseOrders={purchaseOrders}
              suppliers={suppliers}
              currency={settings.currency}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'pos' && (
            <RetailPosView
              items={items}
              categories={categories}
              currency={settings.currency}
              systemDate={systemDate}
              onAddInvoice={handleAddInvoice}
              storeName={settings.storeName}
              brandName={settings.brandName}
              brandShortName={settings.brandShortName}
              logoUrl={settings.logoUrl}
              address={settings.address}
              phone={settings.phone}
            />
          )}

          {currentTab === 'sales' && (
            <SalesInvoiceView
              items={items}
              wholesalers={wholesalers}
              invoices={invoices}
              currency={settings.currency}
              systemDate={systemDate}
              onAddInvoice={handleAddInvoice}
              onUpdateInvoice={handleUpdateInvoice}
              onDeleteInvoice={handleDeleteInvoice}
              searchQuery={searchQuery}
              storeName={settings.storeName}
              brandName={settings.brandName}
              brandShortName={settings.brandShortName}
              logoUrl={settings.logoUrl}
              address={settings.address}
              phone={settings.phone}
            />
          )}

          {currentTab === 'wholesalers' && (
            <WholesalersView
              wholesalers={wholesalers}
              currency={settings.currency}
              onAddWholesaler={handleAddWholesaler}
              onUpdateWholesaler={handleUpdateWholesaler}
              onDeleteWholesaler={handleDeleteWholesaler}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'accounts' && (
            <AccountsView
              accountTxns={accountTxns}
              wholesalers={wholesalers}
              invoices={invoices}
              currency={settings.currency}
              onAddTransaction={handleAddAccountTxn}
              onUpdateWholesalerDue={handleUpdateWholesalerDue}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'expenses' && (
            <ExpensesView
              expenses={expenses}
              invoices={invoices}
              items={items}
              currency={settings.currency}
              userName={userName}
              onAddExpense={handleAddExpense}
              onUpdateExpense={handleUpdateExpense}
              onDeleteExpense={handleDeleteExpense}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'purchase-orders' && (
            <PurchaseOrdersView
              purchaseOrders={purchaseOrders}
              items={items}
              suppliers={suppliers}
              currency={settings.currency}
              onAddPO={handleAddPO}
              onUpdatePO={handleUpdatePO}
              onDeletePO={handleDeletePO}
              onReceivePOItems={handleReceivePOItems}
              searchQuery={searchQuery}
              brandName={settings.brandName}
              storeName={settings.storeName}
              phone={settings.phone}
            />
          )}

          {currentTab === 'expiry-damage' && (
            <ExpiryDamageView
              items={items}
              damagedStockList={damagedStockList}
              currency={settings.currency}
              userName={userName}
              onAddDamagedStock={handleAddDamagedStock}
              onDeleteDamagedStock={handleDeleteDamagedStock}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              items={items}
              transactions={transactions}
              invoices={invoices}
              wholesalers={wholesalers}
              accountTxns={accountTxns}
              suppliers={suppliers}
              categories={categories}
              currency={settings.currency}
              storeName={settings.storeName}
              brandName={settings.brandName}
            />
          )}

          {currentTab === 'inventory' && (
            <InventoryView
              items={items}
              categories={categories}
              suppliers={suppliers}
              currency={settings.currency}
              onAddItem={handleAddItem}
              onUpdateItem={handleUpdateItem}
              onDeleteItem={handleDeleteItem}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'transactions' && (
            <StockTransactionsView
              items={items}
              transactions={transactions}
              currency={settings.currency}
              userName={userName}
              systemDate={systemDate}
              onAddTransaction={handleAddTransaction}
              onUpdateTransaction={handleUpdateTransaction}
              onDeleteTransaction={handleDeleteTransaction}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'suppliers' && (
            <SuppliersView
              suppliers={suppliers}
              onAddSupplier={handleAddSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={handleDeleteSupplier}
              searchQuery={searchQuery}
            />
          )}

          {currentTab === 'categories' && (
            <CategoriesView
              categories={categories}
              onAddCategory={handleAddCategory}
              onUpdateCategory={handleUpdateCategory}
              onDeleteCategory={handleDeleteCategory}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              users={users}
              onAddUser={handleAddUser}
              onUpdateUser={handleUpdateUser}
              onDeleteUser={handleDeleteUser}
              currentUserRole={userRole}
              onResetAllData={handleResetAllData}
              onExportBackupJSON={handleExportBackupJSON}
              onExportBackupCSV={handleExportBackupCSV}
              onImportBackupJSON={handleImportBackupJSON}
            />
          )}
        </main>

        {/* Floating AI Chatbot Assistant */}
        <AiChatbot
          items={items}
          transactions={transactions}
          invoices={invoices}
          wholesalers={wholesalers}
          categories={categories}
          currency={settings.currency}
          brandName={settings.brandName}
          brandShortName={settings.brandShortName}
          logoUrl={settings.logoUrl}
          onNavigateTab={setCurrentTab}
        />
      </div>
    </div>
  );
}

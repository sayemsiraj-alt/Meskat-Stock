import React, { useState } from 'react';
import { StockItem, Category, Supplier } from '../data/mockData';
import { Plus, Filter, Trash2, Edit, AlertCircle, CheckCircle, Package } from 'lucide-react';

interface InventoryViewProps {
  items: StockItem[];
  categories: Category[];
  suppliers: Supplier[];
  currency: string;
  onAddItem: (item: Omit<StockItem, 'id' | 'status'>) => void;
  onUpdateItem: (item: StockItem) => void;
  onDeleteItem: (id: string) => void;
  searchQuery: string;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  items,
  categories,
  suppliers,
  currency,
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  searchQuery
}) => {
  const [selectedCat, setSelectedCat] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  
  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<StockItem | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState(categories[0]?.name || 'Tablets & Capsules');
  const [sku, setSku] = useState('');
  const [batchNo, setBatchNo] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [unit, setUnit] = useState('Boxes');
  const [price, setPrice] = useState<number | ''>('');
  const [costPrice, setCostPrice] = useState<number | ''>('');
  const [supplier, setSupplier] = useState(suppliers[0]?.name || 'Square Pharmaceuticals Ltd');
  const [expiryDate, setExpiryDate] = useState('2027-12-31');
  const [reorderThreshold, setReorderThreshold] = useState<number | ''>('');
  const [location, setLocation] = useState('Aisle 1 - Shelf A');

  // Filter items
  const filteredItems = items.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.batchNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.supplier.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCat = selectedCat === 'All' || item.category === selectedCat;
    
    const matchesStatus = statusFilter === 'All' || 
      (statusFilter === 'Low Stock' && item.quantity <= item.reorderThreshold && item.quantity > 0) ||
      (statusFilter === 'Out of Stock' && item.quantity === 0) ||
      (statusFilter === 'In Stock' && item.quantity > item.reorderThreshold);

    return matchesSearch && matchesCat && matchesStatus;
  });

  const openAddModal = () => {
    setEditingItem(null);
    setName('');
    setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setBatchNo(`B-2026${Math.floor(10 + Math.random() * 90)}`);
    setQuantity(100);
    setPrice(250);
    setCostPrice(200);
    setReorderThreshold(50);
    setLocation('Aisle 1 - Shelf A');
    setIsModalOpen(true);
  };

  const openEditModal = (item: StockItem) => {
    setEditingItem(item);
    setName(item.name);
    setCategory(item.category);
    setSku(item.sku);
    setBatchNo(item.batchNo);
    setQuantity(item.quantity);
    setUnit(item.unit);
    setPrice(item.price);
    setCostPrice(item.costPrice);
    setSupplier(item.supplier);
    setExpiryDate(item.expiryDate);
    setReorderThreshold(item.reorderThreshold);
    setLocation(item.location);
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const finalQuantity = Number(quantity) || 0;
    const finalThreshold = Number(reorderThreshold) || 0;
    const finalPrice = Number(price) || 0;
    const finalCostPrice = Number(costPrice) || 0;

    if (editingItem) {
      const updatedStatus = finalQuantity === 0 ? 'Out of Stock' : (finalQuantity <= finalThreshold ? 'Low Stock' : 'In Stock');
      onUpdateItem({
        ...editingItem,
        name,
        category,
        sku,
        batchNo,
        quantity: finalQuantity,
        unit,
        price: finalPrice,
        costPrice: finalCostPrice,
        supplier,
        expiryDate,
        reorderThreshold: finalThreshold,
        location,
        status: updatedStatus
      });
    } else {
      onAddItem({
        name,
        category,
        sku,
        batchNo,
        quantity: finalQuantity,
        unit,
        price: finalPrice,
        costPrice: finalCostPrice,
        supplier,
        expiryDate,
        reorderThreshold: finalThreshold,
        location,
      });
    }
    setIsModalOpen(false);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto min-h-full">
      
      {/* Top action bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-2xl shadow-xs border border-slate-200">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5 text-emerald-600" />
            <span>Category:</span>
          </div>
          <select
            value={selectedCat}
            onChange={(e) => setSelectedCat(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-700 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
          >
            <option value="All">All Categories</option>
            {categories.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>

          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold uppercase tracking-wider ml-2">
            <span>Status:</span>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-700 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
          >
            <option value="All">All Stock Status</option>
            <option value="In Stock">In Stock</option>
            <option value="Low Stock">Low Stock Alert</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
        </div>

        <button
          onClick={openAddModal}
          className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Stock Item</span>
        </button>
      </div>

      {/* Item List Table */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-4 font-bold">Item Name & SKU</th>
                <th className="p-4 font-bold">Category</th>
                <th className="p-4 font-bold">Batch & Expiry</th>
                <th className="p-4 font-bold">Supplier</th>
                <th className="p-4 font-bold">Available Stock</th>
                <th className="p-4 font-bold">Unit Price</th>
                <th className="p-4 font-bold">Status</th>
                <th className="p-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.map(item => {
                const isOut = item.quantity === 0;
                const isLow = item.quantity <= item.reorderThreshold && item.quantity > 0;
                
                return (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-4">
                      <div className="font-bold text-slate-900 text-xs">{item.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">{item.sku} • {item.location}</div>
                    </td>
                    <td className="p-4 font-medium text-slate-600">{item.category}</td>
                    <td className="p-4">
                      <div className="font-mono text-slate-700 font-semibold">{item.batchNo}</div>
                      <div className="text-[10px] text-slate-500">Exp: {item.expiryDate}</div>
                    </td>
                    <td className="p-4 text-slate-600 text-[11px]">{item.supplier}</td>
                    <td className="p-4 font-bold text-slate-900">
                      <span className={`text-sm ${isOut ? 'text-rose-600 font-extrabold' : isLow ? 'text-amber-600' : 'text-slate-800'}`}>
                        {item.quantity}
                      </span>
                      <span className="text-[10px] text-slate-400 font-normal ml-1">{item.unit}</span>
                      <div className="text-[10px] text-slate-400">Min: {item.reorderThreshold}</div>
                    </td>
                    <td className="p-4 font-bold text-slate-900">
                      <div>{currency} {item.price}</div>
                      <div className="text-[10px] text-slate-400 font-normal">Cost: {currency} {item.costPrice}</div>
                    </td>
                    <td className="p-4">
                      {isOut && (
                        <span className="px-2 py-1 bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[10px] font-bold inline-flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" /> Out of Stock
                        </span>
                      )}
                      {isLow && (
                        <span className="px-2 py-1 bg-amber-100 text-amber-700 border border-amber-200 rounded-lg text-[10px] font-bold inline-flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" /> Low Stock
                        </span>
                      )}
                      {!isOut && !isLow && (
                        <span className="px-2 py-1 bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-[10px] font-bold inline-flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" /> In Stock
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(item)}
                        className="p-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-600 rounded-lg text-slate-600 transition"
                        title="Edit Item"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteItem(item.id)}
                        className="p-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 rounded-lg text-slate-600 transition"
                        title="Delete Item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <Package className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    No inventory items matched your search or filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 sm:p-8 space-y-5 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-800 text-lg">
                {editingItem ? 'Edit Stock Item' : 'Add New Inventory Item'}
              </h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-base font-bold p-1 rounded-lg hover:bg-slate-100 transition"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Item / Medicine Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                    placeholder="e.g. Napa Extend 665mg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">SKU / Code</label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-mono font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Batch Number</label>
                  <input
                    type="text"
                    required
                    value={batchNo}
                    onChange={(e) => setBatchNo(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-mono font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Quantity</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Unit Type</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  >
                    <option value="Boxes">Boxes</option>
                    <option value="Bottles">Bottles</option>
                    <option value="Bags">Bags</option>
                    <option value="Packs">Packs</option>
                    <option value="Tubes">Tubes</option>
                    <option value="Kg">Kg</option>
                    <option value="Pieces">Pieces</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Selling Price ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Cost Price ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={costPrice}
                    onChange={(e) => setCostPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Supplier / Vendor</label>
                  <select
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Reorder Alert Threshold</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={reorderThreshold}
                    onChange={(e) => setReorderThreshold(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Storage Location / Shelf</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                    placeholder="e.g. Aisle 1 - Shelf A"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-extrabold text-slate-600 hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-extrabold text-xs shadow-md hover:from-emerald-600 hover:to-cyan-600 transition transform hover:-translate-y-0.5"
                >
                  {editingItem ? 'Save Updates' : 'Add Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

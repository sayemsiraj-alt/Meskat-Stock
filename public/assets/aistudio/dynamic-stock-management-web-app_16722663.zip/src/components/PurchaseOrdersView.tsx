import React, { useState } from 'react';
import { PurchaseOrder, StockItem, Supplier } from '../data/mockData';
import { 
  Printer, 
  Trash2, 
  MessageSquare, 
  AlertTriangle, 
  Eye
} from 'lucide-react';
import { getFormattedLocalDateTime } from '../utils/dateUtils';

interface PurchaseOrdersViewProps {
  purchaseOrders: PurchaseOrder[];
  items: StockItem[];
  suppliers: Supplier[];
  currency: string;
  onAddPO: (po: Omit<PurchaseOrder, 'id'>) => void;
  onUpdatePO: (po: PurchaseOrder) => void;
  onDeletePO: (id: string) => void;
  onReceivePOItems: (po: PurchaseOrder) => void;
  searchQuery: string;
  brandName: string;
  storeName: string;
  phone: string;
}

export const PurchaseOrdersView: React.FC<PurchaseOrdersViewProps> = ({
  purchaseOrders,
  items,
  suppliers,
  currency,
  onAddPO,
  onDeletePO,
  onReceivePOItems,
  searchQuery,
  brandName,
  storeName,
  phone
}) => {
  const [activePO, setActivePO] = useState<PurchaseOrder | null>(null);

  const formatCurr = (val: number) => {
    const sym = currency.includes('৳') || currency.toLowerCase().includes('bdt') ? '৳' : currency;
    return `${sym} ${val.toLocaleString()}`;
  };

  // Find items running low in stock
  const lowStockItems = items.filter(i => i.quantity <= i.reorderThreshold);

  // Group low stock items by supplier for auto PO generation
  const handleAutoGeneratePOs = () => {
    if (lowStockItems.length === 0) {
      alert('No items are currently below the reorder threshold!');
      return;
    }

    const supplierMap: Record<string, StockItem[]> = {};
    lowStockItems.forEach(item => {
      const sup = item.supplier || 'Unassigned Supplier';
      if (!supplierMap[sup]) supplierMap[sup] = [];
      supplierMap[sup].push(item);
    });

    let generatedCount = 0;
    Object.keys(supplierMap).forEach(supName => {
      const supItems = supplierMap[supName];
      const poItems = supItems.map(i => {
        const reorderQty = Math.max(i.reorderThreshold * 2, 50); // Reorder 2x threshold
        return {
          itemId: i.id,
          itemName: i.name,
          quantity: reorderQty,
          costPrice: i.costPrice,
          total: reorderQty * i.costPrice
        };
      });

      const totalAmount = poItems.reduce((sum, x) => sum + x.total, 0);
      const supplierObj = suppliers.find(s => s.name === supName);
      const poNo = `PO-${new Date().getFullYear()}${String(new Date().getMonth()+1).padStart(2,'0')}-${Math.floor(1000 + Math.random() * 9000)}`;

      onAddPO({
        poNo,
        supplierName: supName,
        supplierPhone: supplierObj?.phone || '',
        items: poItems,
        totalAmount,
        date: getFormattedLocalDateTime(),
        status: 'Draft',
        notes: `Automated reorder PO for ${poItems.length} low-stock items.`
      });
      generatedCount++;
    });

    alert(`Successfully auto-generated ${generatedCount} Purchase Orders for low-stock items!`);
  };

  const filteredPOs = purchaseOrders.filter(po => 
    po.poNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    po.supplierName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSendWhatsAppPO = (po: PurchaseOrder) => {
    const itemsText = po.items.map(i => `• ${i.itemName}: ${i.quantity} Pcs @ ${formatCurr(i.costPrice)} = ${formatCurr(i.total)}`).join('\n');
    const msg = `📋 *PURCHASE REQUISITION ORDER*
🏢 *${brandName}* (${storeName})
------------------------------
PO No: *${po.poNo}*
Date: *${po.date.replace('T', ' ')}*
Supplier: *${po.supplierName}*

*Requested Items:*
${itemsText}

------------------------------
Total Estimated Amount: *${formatCurr(po.totalAmount)}*

Please confirm delivery availability and dispatch timeline. Contact: ${phone}`;

    let cleanPhone = (po.supplierPhone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) cleanPhone = '88' + cleanPhone;

    const url = cleanPhone ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(msg)}` : `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto min-h-full">
      {/* Top Banner */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl shadow-xs border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-extrabold text-slate-800 text-base">Automated Purchase Orders (সাপ্লায়ার পারচেজ অর্ডার)</h3>
          <p className="text-xs text-slate-500 mt-0.5">Auto-generate purchase requisitions for low stock items & send directly to suppliers</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleAutoGeneratePOs}
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-sm transition"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Auto-Draft Low Stock POs ({lowStockItems.length} Low)</span>
          </button>
        </div>
      </div>

      {/* PO Table */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs">
          <span className="font-extrabold text-slate-800 text-sm">Purchase Order Requisitions History</span>
          <span className="font-bold text-slate-600 bg-slate-200 px-2.5 py-1 rounded-lg">{filteredPOs.length} Orders</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-4 font-bold">PO No.</th>
                <th className="p-4 font-bold">Supplier / Vendor</th>
                <th className="p-4 font-bold text-center">Items Count</th>
                <th className="p-4 font-bold text-right">Total Est. Amount</th>
                <th className="p-4 font-bold">Date</th>
                <th className="p-4 font-bold text-center">Status</th>
                <th className="p-4 font-bold text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPOs.map(po => (
                <tr key={po.id} className="hover:bg-slate-50">
                  <td className="p-4 font-mono font-extrabold text-slate-900">{po.poNo}</td>
                  <td className="p-4 font-bold text-blue-700">{po.supplierName}</td>
                  <td className="p-4 text-center font-bold text-slate-800">{po.items.length} Products</td>
                  <td className="p-4 text-right font-mono font-bold text-slate-900">{formatCurr(po.totalAmount)}</td>
                  <td className="p-4 text-slate-500 font-mono">{po.date.replace('T', ' ')}</td>
                  <td className="p-4 text-center">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold ${
                      po.status === 'Received' ? 'bg-emerald-100 text-emerald-800' :
                      po.status === 'Sent' ? 'bg-blue-100 text-blue-800' :
                      po.status === 'Cancelled' ? 'bg-rose-100 text-rose-800' :
                      'bg-amber-100 text-amber-800'
                    }`}>
                      {po.status}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button onClick={() => setActivePO(po)} className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-bold transition flex items-center gap-1" title="View & Print PO">
                        <Eye className="w-3.5 h-3.5" /> View
                      </button>

                      <button onClick={() => handleSendWhatsAppPO(po)} className="p-1.5 bg-emerald-50 hover:bg-emerald-100 rounded-lg text-emerald-700 font-bold transition" title="Send Requisition to Supplier WhatsApp">
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      {po.status !== 'Received' && (
                        <button
                          onClick={() => {
                            if (confirm(`Mark PO ${po.poNo} as Received? This will automatically restock ${po.items.length} product quantities into Inventory!`)) {
                              onReceivePOItems(po);
                            }
                          }}
                          className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold rounded-lg text-[10px] transition"
                        >
                          Receive & Restock
                        </button>
                      )}

                      <button onClick={() => onDeletePO(po.id)} className="p-1.5 hover:text-rose-600 transition" title="Delete PO">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredPOs.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-10 text-center text-slate-400">No Purchase Orders found. Click 'Auto-Draft Low Stock POs' to generate.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PRINTABLE PO MODAL */}
      {activePO && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 sm:p-8 space-y-5 relative my-8 text-slate-900">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 no-print">
              <h4 className="font-extrabold text-base text-slate-800">Purchase Order Requisition Memo</h4>
              <div className="flex gap-2">
                <button onClick={() => window.print()} className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1">
                  <Printer className="w-3.5 h-3.5" /> Print PO
                </button>
                <button onClick={() => setActivePO(null)} className="text-slate-400 hover:text-slate-600 font-bold p-1">✕</button>
              </div>
            </div>

            <div id="printable-po-memo" className="p-6 border border-slate-300 rounded-2xl space-y-5 bg-white text-slate-900">
              <div className="flex justify-between items-start pb-4 border-b-2 border-slate-900">
                <div>
                  <h3 className="text-xl font-black uppercase text-slate-950">{brandName}</h3>
                  <p className="text-xs font-bold text-slate-700">{storeName}</p>
                  <p className="text-[11px] text-slate-600">Tel: {phone}</p>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 bg-slate-900 text-white font-extrabold text-xs uppercase rounded">PURCHASE ORDER</span>
                  <p className="text-xs font-mono font-bold mt-1">PO No: <strong>{activePO.poNo}</strong></p>
                  <p className="text-[11px] font-mono text-slate-600">Date: {activePO.date.replace('T', ' ')}</p>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                <span className="font-extrabold uppercase text-slate-500 block mb-1">Supplier / Vendor:</span>
                <p className="font-extrabold text-sm text-slate-950">{activePO.supplierName}</p>
                <p className="text-slate-600">Phone: {activePO.supplierPhone || 'N/A'}</p>
              </div>

              <table className="w-full text-left text-xs border border-slate-300 rounded-xl overflow-hidden">
                <thead className="bg-slate-100 font-extrabold text-slate-900 uppercase">
                  <tr>
                    <th className="p-3 border-r border-slate-300">Product Description</th>
                    <th className="p-3 text-center border-r border-slate-300">Qty</th>
                    <th className="p-3 text-right border-r border-slate-300">Unit Cost ({currency})</th>
                    <th className="p-3 text-right">Est. Total ({currency})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-medium">
                  {activePO.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="p-3 border-r border-slate-200 font-bold">{item.itemName}</td>
                      <td className="p-3 text-center border-r border-slate-200 font-bold">{item.quantity}</td>
                      <td className="p-3 text-right border-r border-slate-200 font-mono">{item.costPrice}</td>
                      <td className="p-3 text-right font-mono font-bold">{item.total.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="flex justify-end pt-2">
                <div className="w-60 bg-slate-50 border border-slate-300 p-3 rounded-xl text-xs flex justify-between font-extrabold text-slate-950">
                  <span>Grand Total Est.:</span>
                  <span className="font-mono">{formatCurr(activePO.totalAmount)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

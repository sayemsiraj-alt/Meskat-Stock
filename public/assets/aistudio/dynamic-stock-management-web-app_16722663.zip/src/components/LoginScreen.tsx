import React, { useState } from 'react';
import { User, Key, ArrowRight, Sparkles } from 'lucide-react';
import { SystemUser, SystemSettings } from '../data/mockData';
import { CompanyLogo } from './CompanyLogo';

interface LoginScreenProps {
  onLogin: (user: SystemUser, rememberMe: boolean) => void;
  users: SystemUser[];
  settings: SystemSettings;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, users, settings }) => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId.trim() || !password) {
      setError('Please enter User ID and Password');
      return;
    }

    const user = users.find(u => u.userId === userId && u.passwordHash === password);
    if (!user) {
      setError('Invalid User ID or Password. Please try again.');
      return;
    }

    if (user.status === 'Inactive') {
      setError('This account has been deactivated. Contact Admin.');
      return;
    }

    onLogin(user, rememberMe);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Background Decorative Blobs */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-700 p-8 z-10">
        
        {/* Header / Logo */}
        <div className="text-center mb-8">
          <CompanyLogo className="w-28 h-28 mx-auto mb-4 ring-8 ring-emerald-500/10" shortName={settings.brandShortName} logoUrl={settings.logoUrl} />
          <h1 className="text-3xl font-extrabold text-white tracking-tight">{settings.brandName}</h1>
          <p className="text-emerald-400 font-medium text-sm mt-1">Automatic Stock Management Web App</p>
          <div className="flex items-center justify-center gap-1 mt-2 text-xs text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Fully Dynamic & Real-time Automated</span>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-500/20 border border-rose-500/50 rounded-lg text-rose-300 text-xs font-medium text-center">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 uppercase tracking-wider mb-1.5">User ID</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                placeholder="Enter User ID"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 uppercase tracking-wider mb-1.5">Password</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Key className="w-4 h-4" />
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                placeholder="Enter Password"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-300 hover:text-white transition">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 text-emerald-500 bg-slate-900 border-slate-700 rounded focus:ring-emerald-500 cursor-pointer"
              />
              <span>Remember login on this device</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full mt-6 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-950 font-bold py-3 px-4 rounded-xl shadow-lg transition duration-200 flex items-center justify-center gap-2 transform hover:translate-y-[-1px]"
          >
            <span>Login to Management System</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};

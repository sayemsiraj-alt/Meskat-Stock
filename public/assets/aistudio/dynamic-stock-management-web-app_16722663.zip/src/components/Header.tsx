import React, { useState, useRef, useEffect } from 'react';
import { 
  Bell, 
  Search, 
  Calendar, 
  ShieldCheck, 
  Menu, 
  LogOut, 
  Settings, 
  AlertTriangle, 
  CheckCircle2,
  Key,
  User,
  X,
  Lock
} from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';
import { SystemUser } from '../data/mockData';
import { getThemeConfig, ThemeId } from '../utils/themeConfig';

interface HeaderProps {
  currentTab: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  userName: string;
  userRole: string;
  currentUser?: SystemUser;
  onUpdateProfile?: (updatedUser: SystemUser) => void;
  storeName: string;
  brandName?: string;
  brandShortName: string;
  logoUrl?: string;
  systemDate: string;
  onSystemDateChange: (newDate: string) => void;
  onToggleSidebar: () => void;
  onLogout: () => void;
  onSelectTab: (tab: string) => void;
  lowStockCount: number;
  activeTheme?: ThemeId;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  searchQuery,
  onSearchChange,
  userName,
  userRole,
  currentUser,
  onUpdateProfile,
  storeName,
  brandName,
  brandShortName,
  logoUrl,
  systemDate,
  onSystemDateChange,
  onToggleSidebar,
  onLogout,
  onSelectTab,
  lowStockCount,
  activeTheme
}) => {
  const theme = getThemeConfig(activeTheme);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  
  // Profile Modal State
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [editName, setEditName] = useState(currentUser?.name || userName);
  const [editUserId, setEditUserId] = useState(currentUser?.userId || '');
  const [editPassword, setEditPassword] = useState(currentUser?.passwordHash || '');
  const [editProfilePic, setEditProfilePic] = useState(currentUser?.profilePicUrl || '');
  const [profileMsg, setProfileMsg] = useState('');

  const openProfileModal = () => {
    setEditName(currentUser?.name || userName);
    setEditUserId(currentUser?.userId || '');
    setEditPassword(currentUser?.passwordHash || '');
    setEditProfilePic(currentUser?.profilePicUrl || '');
    setProfileMsg('');
    setIsProfileModalOpen(true);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editUserId.trim() || !editPassword.trim()) {
      alert('User ID and Password cannot be empty.');
      return;
    }

    if (currentUser && onUpdateProfile) {
      onUpdateProfile({
        ...currentUser,
        name: editName.trim() || userName,
        userId: editUserId.trim(),
        passwordHash: editPassword.trim(),
        profilePicUrl: editProfilePic
      });
      setProfileMsg('User Profile, ID, Password & Photo updated successfully!');
      setTimeout(() => {
        setProfileMsg('');
        setIsProfileModalOpen(false);
      }, 1500);
    } else {
      setIsProfileModalOpen(false);
    }
  };

  const notifRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Close dropdowns if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getTabTitle = () => {
    switch (currentTab) {
      case 'dashboard': return 'Central Stock Dashboard';
      case 'pos': return 'Retail POS Counter Sales (খুচরা বিক্রয়)';
      case 'sales': return 'Wholesale Sales & Chalans';
      case 'wholesalers': return 'Wholesale Customers';
      case 'accounts': return 'Accounts & Ledgers';
      case 'expenses': return 'Expense Management & Net Profit';
      case 'purchase-orders': return 'Automated Purchase Orders (PO)';
      case 'expiry-damage': return 'Expiry Tracker & Damaged Stock';
      case 'reports': return 'Stock Reports & Summary';
      case 'inventory': return 'Inventory Management';
      case 'transactions': return 'Stock Transactions & Logging';
      case 'suppliers': return 'Suppliers & Distributors';
      case 'categories': return 'Categories & Storage Aisles';
      case 'settings': return 'System Settings & Config';
      default: return brandName || storeName || 'Stock Management System';
    }
  };

  return (
    <header className={`h-16 ${theme.headerBgClass} border-b px-4 sm:px-6 flex items-center justify-between sticky top-0 z-20 shadow-xs`}>
      {/* Left side: Hamburger (Mobile) + Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 text-slate-600 hover:text-slate-900 lg:hidden rounded-xl hover:bg-slate-100 transition"
          aria-label="Toggle Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h2 className={`text-base sm:text-lg font-black ${theme.headerTitleClass} tracking-tight truncate max-w-[150px] sm:max-w-none`}>
            {getTabTitle()}
          </h2>
          <p className="text-xs text-slate-500 font-semibold hidden sm:flex items-center gap-1.5">
            <CompanyLogo className="w-4.5 h-4.5 border-teal-200" shortName={brandShortName} logoUrl={logoUrl} />
            <span className="truncate max-w-[200px]">{storeName}</span>
          </p>
        </div>
      </div>

      {/* Right side controls */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Global Search bar */}
        <div className="relative w-36 sm:w-64 md:w-72">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-1.5 sm:py-2 pl-8 sm:pl-9 pr-3 text-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
            placeholder="Search items..."
          />
        </div>

        {/* Date capsule / System Date selector */}
        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200/80 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 transition" title="Working System Date (Click to change)">
          <Calendar className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <input
            type="date"
            value={systemDate}
            onChange={(e) => onSystemDateChange(e.target.value)}
            className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer"
          />
        </div>

        {/* Notification Bell Dropdown */}
        <div className="relative" ref={notifRef}>
          <button 
            onClick={() => {
              setShowNotifications(prev => !prev);
              setShowUserMenu(false);
            }}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center transition ${
              showNotifications 
                ? 'bg-emerald-50 text-emerald-600 ring-2 ring-emerald-500/20' 
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
            title="View Notifications"
          >
            <Bell className="w-4 h-4" />
            {lowStockCount > 0 ? (
              <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white animate-pulse"></span>
            ) : (
              <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full ring-2 ring-white"></span>
            )}
          </button>

          {/* Popover notifications */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-fade-in z-30">
              <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">System Notifications</span>
                <span className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full">
                  {lowStockCount > 0 ? `${lowStockCount} Alerts` : 'System OK'}
                </span>
              </div>

              <div className="max-h-64 overflow-y-auto divide-y divide-slate-50 text-xs">
                {lowStockCount > 0 ? (
                  <div 
                    onClick={() => {
                      onSelectTab('inventory');
                      setShowNotifications(false);
                    }}
                    className="p-3 bg-amber-50/60 hover:bg-amber-50 cursor-pointer flex items-start gap-2 transition"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-amber-900 text-xs">Low Inventory Warning</p>
                      <p className="text-[11px] text-amber-700 mt-0.5">
                        {lowStockCount} stock items have dropped below their critical reorder threshold. Click to view stock status.
                      </p>
                      <span className="text-[9px] text-amber-500 font-bold block mt-1">Just now</span>
                    </div>
                  </div>
                ) : null}

                <div className="p-3 hover:bg-slate-50 flex items-start gap-2 transition">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-slate-800 text-xs">Dear Health Care Automation Active</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Daily summaries and transaction recalculations are running optimally.
                    </p>
                    <span className="text-[9px] text-slate-400 block mt-1">Today</span>
                  </div>
                </div>

                <div className="p-3 hover:bg-slate-50 flex items-start gap-2 transition">
                  <ShieldCheck className="w-4 h-4 text-cyan-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-slate-800 text-xs">Login Successful</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Session established for {userName}. Access levels verified.
                    </p>
                    <span className="text-[9px] text-slate-400 block mt-1">System boot</span>
                  </div>
                </div>
              </div>

              <div className="p-2 bg-slate-50 border-t border-slate-100 text-center">
                <button 
                  onClick={() => setShowNotifications(false)}
                  className="text-[11px] text-slate-500 hover:text-slate-800 font-bold"
                >
                  Dismiss Menu
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="h-5 w-px bg-slate-200 hidden sm:block"></div>

        {/* User profile with 'A' Icon Dropdown Menu */}
        <div className="relative" ref={userMenuRef}>
          <button 
            onClick={() => {
              setShowUserMenu(prev => !prev);
              setShowNotifications(false);
            }}
            className="flex items-center gap-2 text-left rounded-xl hover:bg-slate-50 p-1 transition"
            title="User Options"
          >
            <div className="hidden md:block text-right">
              <span className="text-xs font-bold text-slate-800 block truncate max-w-[100px]">
                {userName.split(' ')[0]}
              </span>
              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5 justify-end uppercase">
                <ShieldCheck className="w-2.5 h-2.5 inline" /> {userRole}
              </span>
            </div>

            {/* Avatar block with letter or picture */}
            <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-cyan-600 text-white font-bold flex items-center justify-center text-xs shadow-xs ring-2 overflow-hidden ${
              showUserMenu ? 'ring-emerald-500' : 'ring-transparent'
            }`}>
              {currentUser?.profilePicUrl ? (
                <img src={currentUser.profilePicUrl} alt={userName} className="w-full h-full object-cover rounded-xl" />
              ) : (
                userName.charAt(0)
              )}
            </div>
          </button>

          {/* User Popover menu */}
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-fade-in z-30 py-1">
              {/* Profile Overview */}
              <div className="px-4 py-3 bg-slate-50 border-b border-slate-100">
                <p className="text-xs font-bold text-slate-900 truncate">{userName}</p>
                <p className="text-[10px] font-semibold text-slate-500 uppercase mt-0.5">Role: {userRole}</p>
              </div>

              {/* Menu items */}
              <div className="py-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    openProfileModal();
                  }}
                  className="w-full px-4 py-2 text-left text-xs text-emerald-700 font-bold hover:bg-emerald-50 flex items-center gap-2 transition"
                >
                  <Key className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Change My User ID & Password</span>
                </button>

                <button
                  onClick={() => {
                    onSelectTab('settings');
                    setShowUserMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 font-medium flex items-center gap-2 transition"
                >
                  <Settings className="w-3.5 h-3.5 text-slate-400" />
                  <span>System Settings</span>
                </button>
              </div>

              <div className="border-t border-slate-100 py-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onLogout();
                  }}
                  className="w-full px-4 py-2 text-left text-xs text-rose-600 hover:bg-rose-50 font-bold flex items-center gap-2 transition"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-500" />
                  <span>Log Out Session</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* --- USER CHANGE USER ID & PASSWORD MODAL --- */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-sm w-full p-6 space-y-4 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 font-extrabold text-slate-800 text-base">
                <Lock className="w-4 h-4 text-emerald-600" />
                <span>Change User ID & Password</span>
              </div>
              <button
                type="button"
                onClick={() => setIsProfileModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {profileMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{profileMsg}</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              {/* Profile Photo Upload */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center font-bold text-white text-base border border-slate-300 shrink-0 overflow-hidden">
                  {editProfilePic ? (
                    <img src={editProfilePic} alt="Profile Preview" className="w-full h-full object-cover rounded-full" />
                  ) : (
                    editName.charAt(0) || 'U'
                  )}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase">Profile Picture (Photo)</label>
                  <label className="cursor-pointer bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold transition inline-block">
                    <span>📁 Choose Image File</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (evt) => {
                            if (evt.target?.result) {
                              setEditProfilePic(evt.target.result as string);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {editProfilePic && (
                    <button
                      type="button"
                      onClick={() => setEditProfilePic('')}
                      className="text-[10px] text-rose-600 font-bold ml-2 hover:underline inline"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Your Full Name</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-9 pr-3 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Login User ID</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    required
                    value={editUserId}
                    onChange={(e) => setEditUserId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-9 pr-3 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Enter new User ID"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Login Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Key className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    required
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-9 pr-3 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Enter new Password"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsProfileModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-xs transition"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};

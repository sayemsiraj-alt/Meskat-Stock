import React, { useState, useMemo } from 'react';
import { AccountTxn, Invoice, Wholesaler } from '../data/mockData';
import { DollarSign, ArrowUpRight, CheckCircle2, FileText, Users, Phone, MapPin, Receipt } from 'lucide-react';

interface AccountsViewProps {
  accountTxns: AccountTxn[];
  wholesalers: Wholesaler[];
  invoices: Invoice[];
  currency: string;
  onAddTransaction: (txn: Omit<AccountTxn, 'id'>) => void;
  onUpdateWholesalerDue: (id: string, amount: number) => void;
  searchQuery: string;
}

export const AccountsView: React.FC<AccountsViewProps> = ({
  accountTxns,
  wholesalers,
  invoices,
  currency,
  onAddTransaction,
  onUpdateWholesalerDue,
  searchQuery
}) => {
  const [activeTab, setActiveTab] = useState<'wholesaler-due' | 'ledger'>('wholesaler-due');
  const [isCollectModalOpen, setIsModalOpen] = useState(false);
  const [selectedWholesalerId, setSelectedWholesalerId] = useState<string>('');
  const [amount, setAmount] = useState<number | ''>('');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');

  const totalCashIn = useMemo(() => accountTxns.filter(t => t.type === 'IN').reduce((sum, t) => sum + t.amount, 0), [accountTxns]);
  const totalCashOut = useMemo(() => accountTxns.filter(t => t.type === 'OUT').reduce((sum, t) => sum + t.amount, 0), [accountTxns]);
  const currentBalance = totalCashIn - totalCashOut;
  const totalMarketDue = useMemo(() => wholesalers.reduce((sum, w) => sum + w.totalDue, 0), [wholesalers]);

  // Wholesaler-wise summary calculations
  const wholesalerSummary = useMemo(() => {
    return wholesalers.map(w => {
      const wInvoices = invoices.filter(inv => inv.wholesalerId === w.id || inv.wholesalerName === w.name);
      const totalBilled = wInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
      const totalPaidAtSales = wInvoices.reduce((sum, inv) => sum + inv.paidAmount, 0);
      return {
        ...w,
        invoiceCount: wInvoices.length,
        totalBilled,
        totalPaidAtSales
      };
    });
  }, [wholesalers, invoices]);

  // Filtered wholesalers
  const filteredWholesalers = wholesalerSummary.filter(w =>
    w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    w.phone.includes(searchQuery)
  );

  // Filtered transactions
  const filteredTxns = accountTxns.filter(t => 
    t.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
    t.reference.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openCollectForWholesaler = (wholesalerId: string) => {
    setSelectedWholesalerId(wholesalerId);
    setAmount('');
    setReference('');
    setNotes('');
    setIsModalOpen(true);
  };

  const handleCollect = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAmount = Number(amount);
    if (!selectedWholesalerId || finalAmount <= 0) return;

    const w = wholesalers.find(x => x.id === selectedWholesalerId);
    
    // Reduce due
    onUpdateWholesalerDue(selectedWholesalerId, -finalAmount);
    
    // Log transaction
    const localDate = new Date();
    const offset = localDate.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(localDate.getTime() - offset)).toISOString().slice(0, 19);

    onAddTransaction({
      date: localISOTime,
      type: 'IN',
      amount: finalAmount,
      reference: reference || 'DUE-COLLECTION',
      description: `Due collection from ${w?.name}${notes ? ` - ${notes}` : ''}`
    });

    setIsModalOpen(false);
    setAmount('');
    setReference('');
    setNotes('');
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto min-h-full">
      {/* Metrics Header */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-blue-500"></div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Net Cash Balance</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-extrabold text-slate-900">{currency} {currentBalance.toLocaleString()}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-rose-500"></div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Market Due</span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <span className="text-2xl font-extrabold text-rose-600">{currency} {totalMarketDue.toLocaleString()}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-center gap-3 sm:col-span-2 lg:col-span-1">
          <button
            onClick={() => {
              setSelectedWholesalerId('');
              setIsModalOpen(true);
            }}
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold rounded-xl text-xs flex justify-center items-center gap-2 transition shadow-sm"
          >
            <CheckCircle2 className="w-4 h-4" /> Collect Customer Due Payment
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('wholesaler-due')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'wholesaler-due' 
              ? 'bg-emerald-500 text-slate-950 shadow-xs font-extrabold' 
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Wholesaler-Wise Due Breakdown (গ্রাহকভিত্তিক বকেয়া হিসাব)</span>
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'ledger' 
              ? 'bg-cyan-500 text-slate-950 shadow-xs font-extrabold' 
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Cash Ledger & Transactions</span>
        </button>
      </div>

      {/* TAB 1: Wholesaler-Wise Due Breakdown */}
      {activeTab === 'wholesaler-due' && (
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h4 className="font-extrabold text-slate-800 text-sm">Customer / Wholesaler Due Receivables Ledger</h4>
              <p className="text-xs text-slate-500 mt-0.5">কার কাছে কত টাকা পাওনা আছে তার সম্পূর্ণ হিসাব</p>
            </div>
            <span className="text-xs font-bold text-slate-600 bg-slate-200/80 px-2.5 py-1 rounded-lg">
              {filteredWholesalers.length} Customers Listed
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-4 font-bold">Wholesaler Name & Phone</th>
                  <th className="p-4 font-bold">Address</th>
                  <th className="p-4 font-bold text-center">Total Chalans</th>
                  <th className="p-4 font-bold text-right">Total Billed</th>
                  <th className="p-4 font-bold text-right text-emerald-700">Total Advance Paid</th>
                  <th className="p-4 font-bold text-right text-rose-700">Current Outstanding Due (বকেয়া)</th>
                  <th className="p-4 font-bold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredWholesalers.map(w => (
                  <tr key={w.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-4">
                      <div className="font-extrabold text-slate-900 text-xs">{w.name}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400" /> {w.phone || 'N/A'}
                      </div>
                    </td>
                    <td className="p-4 text-slate-600 max-w-xs truncate">
                      <div className="flex items-center gap-1 text-[11px]">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" /> {w.address || 'N/A'}
                      </div>
                    </td>
                    <td className="p-4 text-center font-bold text-slate-800">
                      <span className="bg-slate-100 px-2 py-1 rounded text-slate-700">{w.invoiceCount} Chalans</span>
                    </td>
                    <td className="p-4 text-right font-mono font-bold text-slate-900">
                      {currency} {w.totalBilled.toLocaleString()}
                    </td>
                    <td className="p-4 text-right font-mono font-bold text-emerald-600">
                      {currency} {w.totalPaidAtSales.toLocaleString()}
                    </td>
                    <td className="p-4 text-right font-mono font-extrabold">
                      {w.totalDue > 0 ? (
                        <span className="px-2.5 py-1 bg-rose-100 text-rose-700 border border-rose-200 rounded-lg inline-block text-xs">
                          {currency} {w.totalDue.toLocaleString()}
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg inline-block text-xs">
                          Paid (0 Due)
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-center">
                      {w.totalDue > 0 ? (
                        <button
                          onClick={() => openCollectForWholesaler(w.id)}
                          className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition shadow-xs flex items-center gap-1 mx-auto"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Collect Payment</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-semibold">No Pending Due</span>
                      )}
                    </td>
                  </tr>
                ))}
                {filteredWholesalers.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-10 text-center text-slate-400">
                      No wholesaler records found matching your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Cash Ledger & Transactions */}
      {activeTab === 'ledger' && (
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-800">
              <FileText className="w-4 h-4" />
              <h4 className="font-bold text-sm">Account Cash Ledger History</h4>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-4 font-bold">Ref No.</th>
                  <th className="p-4 font-bold">Type</th>
                  <th className="p-4 font-bold">Amount</th>
                  <th className="p-4 font-bold">Date & Time</th>
                  <th className="p-4 font-bold">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTxns.map(t => (
                  <tr key={t.id} className="hover:bg-slate-50">
                    <td className="p-4 font-mono font-bold text-slate-700">{t.reference}</td>
                    <td className="p-4 font-bold">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${t.type === 'IN' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                        {t.type === 'IN' ? 'CASH IN' : 'CASH OUT'}
                      </span>
                    </td>
                    <td className={`p-4 font-extrabold font-mono ${t.type === 'IN' ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {t.type === 'IN' ? '+' : '-'}{currency} {t.amount.toLocaleString()}
                    </td>
                    <td className="p-4 text-slate-500 font-mono">{t.date.replace('T', ' ')}</td>
                    <td className="p-4 text-slate-700 max-w-xs truncate">{t.description}</td>
                  </tr>
                ))}
                {filteredTxns.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-10 text-center text-slate-400">No account transactions found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Collect Modal */}
      {isCollectModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 sm:p-8 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-800 text-lg">Collect Due Payment</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-base p-1">✕</button>
            </div>
            <form onSubmit={handleCollect} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Select Customer</label>
                <select 
                  value={selectedWholesalerId} 
                  onChange={e => setSelectedWholesalerId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  required
                >
                  <option value="">-- Select Customer --</option>
                  {wholesalers.filter(w => w.totalDue > 0).map(w => (
                    <option key={w.id} value={w.id}>{w.name} (Due: {currency} {w.totalDue.toLocaleString()})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Received Amount ({currency})</label>
                <input
                  type="number" min="1" required
                  value={amount} onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Reference / Receipt No (Optional)</label>
                <input
                  type="text"
                  value={reference} onChange={e => setReference(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  placeholder="e.g. REC-9901"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Notes</label>
                <input
                  type="text"
                  value={notes} onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  placeholder="Cash/bKash/Bank Transfer..."
                />
              </div>
              <div className="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition">Cancel</button>
                <button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold px-6 py-2.5 rounded-xl text-xs shadow-md transition">Confirm Collection</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

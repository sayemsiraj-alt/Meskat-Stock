import React, { useState } from 'react';
import { Wholesaler } from '../data/mockData';
import { Plus, Users, Phone, MapPin, Edit, Trash2 } from 'lucide-react';

interface WholesalersViewProps {
  wholesalers: Wholesaler[];
  currency: string;
  onAddWholesaler: (w: Omit<Wholesaler, 'id' | 'totalDue'>) => void;
  onUpdateWholesaler: (w: Wholesaler) => void;
  onDeleteWholesaler: (id: string) => void;
  searchQuery: string;
}

export const WholesalersView: React.FC<WholesalersViewProps> = ({
  wholesalers,
  currency,
  onAddWholesaler,
  onUpdateWholesaler,
  onDeleteWholesaler,
  searchQuery
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingWholesaler, setEditingWholesaler] = useState<Wholesaler | null>(null);
  
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  const filtered = wholesalers.filter(w => 
    w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    w.phone.includes(searchQuery)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingWholesaler) {
      onUpdateWholesaler({
        ...editingWholesaler,
        name,
        phone,
        address
      });
    } else {
      onAddWholesaler({
        name,
        phone,
        address
      });
    }

    setIsModalOpen(false);
    setEditingWholesaler(null);
  };

  const openAddModal = () => {
    setEditingWholesaler(null);
    setName('');
    setPhone('');
    setAddress('');
    setIsModalOpen(true);
  };

  const openEditModal = (w: Wholesaler) => {
    setEditingWholesaler(w);
    setName(w.name);
    setPhone(w.phone);
    setAddress(w.address);
    setIsModalOpen(true);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto min-h-full">
      <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-extrabold text-slate-800 text-base">Wholesale Customers & Buyers</h3>
          <p className="text-xs text-slate-500 mt-0.5">Manage your buyers, view outstanding dues and contact information.</p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 shadow-sm transition hover:from-emerald-600 hover:to-cyan-600"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Customer</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(w => (
          <div key={w.id} className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6 flex flex-col justify-between hover:shadow-md transition">
            <div>
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 font-bold text-sm border border-blue-100">
                  <Users className="w-5 h-5" />
                </div>
                <div className={`px-2.5 py-1 text-xs font-bold rounded-lg border ${w.totalDue > 0 ? 'bg-rose-50 text-rose-600 border-rose-200' : 'bg-emerald-50 text-emerald-600 border-emerald-200'}`}>
                  Due: {currency} {w.totalDue.toLocaleString()}
                </div>
              </div>

              <h4 className="font-extrabold text-slate-900 text-base mb-3">{w.name}</h4>

              <div className="space-y-2 text-xs text-slate-500 border-t border-slate-100 pt-3">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{w.phone || 'No phone'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{w.address || 'No address'}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-400 font-mono">{w.id}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => openEditModal(w)} className="p-1 hover:text-emerald-600 transition" title="Edit Customer">
                  <Edit className="w-4 h-4" />
                </button>
                <button onClick={() => onDeleteWholesaler(w.id)} className="p-1 hover:text-rose-600 transition" title="Delete Customer">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full bg-white p-12 text-center text-slate-400 rounded-2xl border border-slate-200">
            No customers match your search.
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 sm:p-8 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-800 text-lg">{editingWholesaler ? 'Edit Customer' : 'Add New Customer'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-base p-1">✕</button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Customer / Shop Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Phone Number</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 tracking-wide">Address</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                ></textarea>
              </div>
              <div className="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition">Cancel</button>
                <button type="submit" className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-extrabold text-xs shadow-md hover:from-emerald-600 transition">
                  {editingWholesaler ? 'Update' : 'Save'} Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
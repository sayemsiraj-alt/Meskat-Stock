import React, { useState } from 'react';
import { Invoice, InvoiceItem, StockItem, Wholesaler } from '../data/mockData';
import { Printer, Plus, Trash2, ShoppingCart, User, ArrowRight, Eye, X, FileText, CheckCircle2, Edit, Copy, Check, MessageSquare } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

import { getLocalYYYYMMDD, getFormattedLocalDateTime, extractYYYYMMDD } from '../utils/dateUtils';

interface SalesInvoiceViewProps {
  items: StockItem[];
  wholesalers: Wholesaler[];
  invoices: Invoice[];
  currency: string;
  systemDate?: string;
  onAddInvoice: (inv: Omit<Invoice, 'id'>) => void;
  onUpdateInvoice: (inv: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  searchQuery: string;
  storeName: string;
  brandName: string;
  brandShortName: string;
  logoUrl?: string;
  address: string;
  phone: string;
}

export const SalesInvoiceView: React.FC<SalesInvoiceViewProps> = ({
  items,
  wholesalers,
  invoices,
  currency,
  systemDate,
  onAddInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  searchQuery,
  storeName,
  brandName,
  brandShortName,
  logoUrl,
  address,
  phone
}) => {
  const [view, setView] = useState<'create' | 'history'>('create');

  const formatCurrSymbol = (curr: string) => {
    if (!curr) return '৳';
    if (curr.includes('৳') || curr.toLowerCase().includes('bdt')) return '৳';
    return curr;
  };
  
  // Create state
  const [selectedWholesalerId, setSelectedWholesalerId] = useState<string>('');
  const [chalanDate, setChalanDate] = useState<string>(systemDate || getLocalYYYYMMDD());
  const [cart, setCart] = useState<InvoiceItem[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<string>('');
  const [qty, setQty] = useState<number | ''>('');
  const [paidAmount, setPaidAmount] = useState<number | ''>('');

  // Invoice Preview / Print Modal State
  const [activeInvoice, setActiveInvoice] = useState<Invoice | null>(null);

  // Edit Modal State
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [editWholesalerId, setEditWholesalerId] = useState<string>('');
  const [editChalanDate, setEditChalanDate] = useState<string>(systemDate || getLocalYYYYMMDD());
  const [editCart, setEditCart] = useState<InvoiceItem[]>([]);
  const [editPaidAmount, setEditPaidAmount] = useState<number | ''>('');
  const [editSelectedItemId, setEditSelectedItemId] = useState<string>('');
  const [editQty, setEditQty] = useState<number | ''>('');

  // Copy share feedback
  const [copied, setCopied] = useState<boolean>(false);

  // Open Edit Modal for an Invoice
  const handleOpenEditModal = (inv: Invoice) => {
    setEditingInvoice(inv);
    setEditWholesalerId(inv.wholesalerId);
    setEditChalanDate(extractYYYYMMDD(inv.date));
    setEditCart([...inv.items]);
    setEditPaidAmount(inv.paidAmount);
    setEditSelectedItemId('');
    setEditQty('');
  };

  const handleEditAddToCart = (e: React.FormEvent) => {
    e.preventDefault();
    const finalQty = Number(editQty);
    if (!editSelectedItemId || finalQty <= 0) return;

    const item = items.find(i => i.id === editSelectedItemId);
    if (!item) return;

    const existing = editCart.find(c => c.itemId === editSelectedItemId);
    if (existing) {
      const newQty = existing.quantity + finalQty;
      setEditCart(editCart.map(c => c.itemId === editSelectedItemId ? { ...c, quantity: newQty, total: newQty * c.unitPrice } : c));
    } else {
      setEditCart([...editCart, {
        itemId: item.id,
        itemName: item.name,
        quantity: finalQty,
        unitPrice: item.price,
        total: finalQty * item.price
      }]);
    }
    setEditQty('');
    setEditSelectedItemId('');
  };

  const removeEditCartItem = (itemId: string) => {
    setEditCart(editCart.filter(c => c.itemId !== itemId));
  };

  const handleSaveEditInvoice = () => {
    if (!editingInvoice) return;
    if (!editWholesalerId) {
      alert('Please select a customer.');
      return;
    }
    if (editCart.length === 0) {
      alert('Cart is empty.');
      return;
    }

    const wholesaler = wholesalers.find(w => w.id === editWholesalerId);
    if (!wholesaler) return;

    const editSubTotal = editCart.reduce((sum, i) => sum + i.total, 0);
    const pAmt = Number(editPaidAmount) || 0;
    const dueAmt = editSubTotal - pAmt;
    const status = dueAmt <= 0 ? 'Paid' : (pAmt > 0 ? 'Partial' : 'Unpaid');

    const updatedInv: Invoice = {
      ...editingInvoice,
      wholesalerId: wholesaler.id,
      wholesalerName: wholesaler.name,
      items: editCart,
      totalAmount: editSubTotal,
      paidAmount: pAmt,
      dueAmount: dueAmt,
      date: getFormattedLocalDateTime(editChalanDate),
      status
    };

    onUpdateInvoice(updatedInv);
    setEditingInvoice(null);
    alert(`Chalan ${updatedInv.chalanNo} updated successfully!`);
  };

  // Helper for generating text summary
  const getInvoiceSummaryText = (inv: Invoice) => {
    const cust = wholesalers.find(w => w.id === inv.wholesalerId || w.name === inv.wholesalerName);
    const currSym = formatCurrSymbol(currency);
    const itemsList = inv.items.map(item => `• ${item.itemName} (${item.quantity} x ${currSym}${item.unitPrice}) = ${currSym}${item.total.toLocaleString()}`).join('\n');

    return `🧾 *SALES CHALAN / INVOICE*
🏢 *${brandName}*
------------------------------
Chalan No: *${inv.chalanNo}*
Date: *${inv.date.replace('T', ' ')}*
Customer: *${inv.wholesalerName}* ${cust?.phone ? `(${cust.phone})` : ''}

📦 *Items Purchased:*
${itemsList}

------------------------------
Grand Total: *${currSym} ${inv.totalAmount.toLocaleString()}*
Advance Paid: *${currSym} ${inv.paidAmount.toLocaleString()}*
Net Due Remaining: *${currSym} ${inv.dueAmount.toLocaleString()}*
Status: *${inv.status.toUpperCase()}*

Thank you for doing business with us!`;
  };

  const handleShareWhatsApp = (inv: Invoice) => {
    const cust = wholesalers.find(w => w.id === inv.wholesalerId || w.name === inv.wholesalerName);
    const textMsg = getInvoiceSummaryText(inv);
    const encodedMsg = encodeURIComponent(textMsg);
    
    // Clean phone number
    let rawPhone = cust?.phone || '';
    let cleanPhone = rawPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '88' + cleanPhone; // Default BD country code
    }

    const waUrl = cleanPhone ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}` : `https://api.whatsapp.com/send?text=${encodedMsg}`;
    window.open(waUrl, '_blank');
  };

  const handleCopySummary = (inv: Invoice) => {
    const textMsg = getInvoiceSummaryText(inv);
    navigator.clipboard.writeText(textMsg);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  // Search filter
  const filteredInvoices = invoices.filter(i => 
    i.chalanNo.toLowerCase().includes(searchQuery.toLowerCase()) || 
    i.wholesalerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const subTotal = cart.reduce((sum, item) => sum + item.total, 0);

  const handleAddToCart = (e: React.FormEvent) => {
    e.preventDefault();
    const finalQty = Number(qty);
    if (!selectedItemId || finalQty <= 0) return;

    const item = items.find(i => i.id === selectedItemId);
    if (!item) return;

    if (finalQty > item.quantity) {
      alert(`Only ${item.quantity} available in stock!`);
      return;
    }

    const existing = cart.find(c => c.itemId === selectedItemId);
    if (existing) {
      const newQty = existing.quantity + finalQty;
      if (newQty > item.quantity) {
        alert(`Adding this exceeds available stock (${item.quantity}).`);
        return;
      }
      setCart(cart.map(c => c.itemId === selectedItemId ? { ...c, quantity: newQty, total: newQty * c.unitPrice } : c));
    } else {
      setCart([...cart, {
        itemId: item.id,
        itemName: item.name,
        quantity: finalQty,
        unitPrice: item.price,
        total: finalQty * item.price
      }]);
    }
    setQty('');
    setSelectedItemId('');
  };

  const removeCartItem = (itemId: string) => {
    setCart(cart.filter(c => c.itemId !== itemId));
  };

  const handleCheckout = () => {
    if (!selectedWholesalerId) {
      alert('Please select a customer.');
      return;
    }
    if (cart.length === 0) {
      alert('Cart is empty.');
      return;
    }

    const wholesaler = wholesalers.find(w => w.id === selectedWholesalerId);
    if (!wholesaler) return;

    const pAmt = Number(paidAmount) || 0;
    const dueAmt = subTotal - pAmt;
    const status = dueAmt <= 0 ? 'Paid' : (pAmt > 0 ? 'Partial' : 'Unpaid');

    const formattedDate = getFormattedLocalDateTime(chalanDate);
    
    // Create CHALAN NO
    const chalanNo = `CH-${new Date().getFullYear()}${String(new Date().getMonth()+1).padStart(2,'0')}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newInv: Omit<Invoice, 'id'> = {
      chalanNo,
      wholesalerId: wholesaler.id,
      wholesalerName: wholesaler.name,
      items: cart,
      totalAmount: subTotal,
      paidAmount: pAmt,
      dueAmount: dueAmt,
      date: formattedDate,
      status
    };

    onAddInvoice(newInv);

    setCart([]);
    setPaidAmount('');
    setSelectedWholesalerId('');

    // Open printable memo
    setActiveInvoice({ ...newInv, id: 'NEW' });
    setView('history');
  };

  const handleOpenInvoiceModal = (inv: Invoice) => {
    setActiveInvoice(inv);
  };

  const triggerPrint = () => {
    window.print();
  };

  const activeCustomer = activeInvoice ? wholesalers.find(w => w.id === activeInvoice.wholesalerId || w.name === activeInvoice.wholesalerName) : null;

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto min-h-full">
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button onClick={() => setView('create')} className={`px-4 py-2 rounded-xl text-xs font-bold transition ${view === 'create' ? 'bg-emerald-500 text-slate-950 shadow-xs font-extrabold' : 'text-slate-600 hover:bg-slate-100'}`}>🛒 POS / Create Chalan</button>
        <button onClick={() => setView('history')} className={`px-4 py-2 rounded-xl text-xs font-bold transition ${view === 'history' ? 'bg-cyan-500 text-slate-950 shadow-xs font-extrabold' : 'text-slate-600 hover:bg-slate-100'}`}>🧾 Sales History & Chalans</button>
      </div>

      {view === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-5 rounded-2xl shadow-xs border border-slate-200">
              <h4 className="font-bold text-slate-800 text-sm mb-4">Add Items to Chalan</h4>
              <form onSubmit={handleAddToCart} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Select Product</label>
                  <select value={selectedItemId} onChange={e => setSelectedItemId(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Choose Item --</option>
                    {items.filter(i => i.quantity > 0).map(i => (
                      <option key={i.id} value={i.id}>{i.name} (Stock: {i.quantity} {i.unit}) - {currency}{i.price}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Quantity</label>
                  <input type="number" min="1" required value={qty} onChange={e => setQty(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Qty" />
                </div>
                <div className="flex items-end">
                  <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold py-2 rounded-xl text-xs flex justify-center items-center gap-1 transition">
                    <Plus className="w-4 h-4" /> Add Item
                  </button>
                </div>
              </form>
            </div>

            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-slate-700 text-sm flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" /> Current Order Items
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-600 uppercase tracking-wider text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-4 font-bold">Item Name</th>
                      <th className="p-4 font-bold text-center">Qty</th>
                      <th className="p-4 font-bold text-right">Unit Price</th>
                      <th className="p-4 font-bold text-right">Total</th>
                      <th className="p-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {cart.map(c => (
                      <tr key={c.itemId} className="hover:bg-slate-50">
                        <td className="p-4 font-bold text-slate-800">{c.itemName}</td>
                        <td className="p-4 font-extrabold text-slate-900 text-center">{c.quantity}</td>
                        <td className="p-4 text-right font-mono">{currency} {c.unitPrice}</td>
                        <td className="p-4 text-right font-mono font-bold">{currency} {c.total.toLocaleString()}</td>
                        <td className="p-4 text-right">
                          <button onClick={() => removeCartItem(c.itemId)} className="text-rose-500 hover:bg-rose-50 p-1.5 rounded-lg transition"><Trash2 className="w-4 h-4" /></button>
                        </td>
                      </tr>
                    ))}
                    {cart.length === 0 && <tr><td colSpan={5} className="p-10 text-center text-slate-400">Cart is currently empty</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-2xl shadow-xs border border-slate-800 p-6 flex flex-col justify-between text-white">
            <div>
              <h4 className="font-extrabold text-lg mb-6 flex items-center gap-2"><User className="w-5 h-5 text-emerald-400" /> Checkout Details</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Select Customer</label>
                  <select value={selectedWholesalerId} onChange={e => setSelectedWholesalerId(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Choose Buyer --</option>
                    {wholesalers.map(w => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Chalan Date *</label>
                  <input
                    type="date"
                    required
                    value={chalanDate}
                    onChange={(e) => setChalanDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  />
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <div className="flex justify-between items-center text-sm mb-2">
                    <span className="text-slate-400">Subtotal:</span>
                    <span className="font-mono font-bold text-white">{currency} {subTotal.toLocaleString()}</span>
                  </div>
                  
                  <div className="mt-4">
                    <label className="block text-[11px] font-bold text-emerald-400 uppercase mb-1">Cash Advance / Paid Amount</label>
                    <input type="number" min="0" value={paidAmount} onChange={e => setPaidAmount(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm font-bold text-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="0" />
                  </div>

                  <div className="flex justify-between items-center text-base mt-4 pt-4 border-t border-slate-800">
                    <span className="text-slate-300 font-bold">Due Amount:</span>
                    <span className={`font-mono font-extrabold ${subTotal - (Number(paidAmount)||0) > 0 ? 'text-rose-400' : 'text-slate-200'}`}>
                      {currency} {Math.max(0, subTotal - (Number(paidAmount)||0)).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <button onClick={handleCheckout} className="mt-8 w-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-950 font-extrabold py-3.5 rounded-xl text-sm shadow-lg flex justify-center items-center gap-2 transition">
              Confirm & Generate Chalan <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {view === 'history' && (
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <FileText className="w-4 h-4" />
              <span>Sales Chalans & Invoice History</span>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-4 font-bold">Chalan No.</th>
                  <th className="p-4 font-bold">Customer Name</th>
                  <th className="p-4 font-bold">Date & Time</th>
                  <th className="p-4 font-bold text-right">Grand Total</th>
                  <th className="p-4 font-bold text-right">Paid Advance</th>
                  <th className="p-4 font-bold text-right">Due Left</th>
                  <th className="p-4 font-bold text-center">Status</th>
                  <th className="p-4 font-bold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-50">
                    <td className="p-4 font-mono font-bold text-slate-900">{inv.chalanNo}</td>
                    <td className="p-4 font-bold text-blue-700">{inv.wholesalerName}</td>
                    <td className="p-4 text-slate-500 font-mono">{inv.date.replace('T', ' ')}</td>
                    <td className="p-4 font-mono font-bold text-slate-900 text-right">{currency} {inv.totalAmount.toLocaleString()}</td>
                    <td className="p-4 font-mono font-bold text-emerald-600 text-right">{currency} {inv.paidAmount.toLocaleString()}</td>
                    <td className="p-4 font-mono font-bold text-rose-600 text-right">{currency} {inv.dueAmount.toLocaleString()}</td>
                    <td className="p-4 text-center">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold inline-block ${
                        inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' : inv.status === 'Partial' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button 
                          onClick={() => handleOpenInvoiceModal(inv)} 
                          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition inline-flex items-center gap-1 shadow-xs"
                          title="View / Print Chalan"
                        >
                          <Eye className="w-3.5 h-3.5" /> View / Print
                        </button>
                        
                        <button 
                          onClick={() => handleShareWhatsApp(inv)} 
                          className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs transition"
                          title="Share to WhatsApp"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>

                        <button 
                          onClick={() => handleOpenEditModal(inv)} 
                          className="p-1.5 bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-600 font-bold rounded-xl text-xs transition"
                          title="Edit Chalan"
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        <button 
                          onClick={() => onDeleteInvoice(inv.id)} 
                          className="p-1.5 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 font-bold rounded-xl text-xs transition"
                          title="Delete Chalan"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredInvoices.length === 0 && <tr><td colSpan={8} className="p-10 text-center text-slate-400">No chalans/invoices found.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- BEAUTIFUL PRINTABLE SALES CHALAN INVOICE MODAL --- */}
      {activeInvoice && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full p-6 sm:p-8 space-y-6 relative my-8">
            
            {/* Modal Control Header (Hidden when printing) */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 no-print">
              <div className="flex items-center gap-2 text-slate-800 font-extrabold text-base">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>Sales Chalan Preview & Options</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => handleShareWhatsApp(activeInvoice)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs transition shadow-xs flex items-center gap-1.5"
                  title="Share Chalan Details directly to Wholesaler WhatsApp"
                >
                  <MessageSquare className="w-4 h-4" /> WhatsApp Share
                </button>

                <button
                  type="button"
                  onClick={() => handleCopySummary(activeInvoice)}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold rounded-xl text-xs transition flex items-center gap-1.5"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
                  <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
                </button>

                <button
                  type="button"
                  onClick={triggerPrint}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl text-xs transition shadow-xs flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" /> Print / PDF
                </button>

                <button
                  type="button"
                  onClick={() => setActiveInvoice(null)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition font-bold"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* PRINTABLE CHALAN CONTAINER */}
            <div id="printable-chalan" className="bg-white p-6 sm:p-8 border border-slate-200 rounded-2xl shadow-xs space-y-6 text-slate-900">
              
              {/* Header Section */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b-2 border-slate-900">
                <div className="flex items-center gap-3">
                  <CompanyLogo className="w-16 h-16" shortName={brandShortName} logoUrl={logoUrl} />
                  <div>
                    <h2 className="text-2xl font-black uppercase tracking-tight text-slate-950">{brandName}</h2>
                    <p className="text-sm font-bold text-slate-900 mt-0.5">{storeName}</p>
                    <p className="text-xs text-slate-900 font-medium mt-1">{address} • Tel: {phone}</p>
                  </div>
                </div>

                <div className="sm:text-right">
                  <span className="inline-block px-3 py-1 bg-slate-950 text-white text-xs font-extrabold uppercase tracking-widest rounded-md mb-1.5">
                    SALES CHALAN / INVOICE
                  </span>
                  <p className="text-sm font-mono font-bold text-slate-950">No: <span className="text-slate-950 font-extrabold">{activeInvoice.chalanNo}</span></p>
                  <p className="text-xs text-slate-900 font-mono font-medium mt-1">Date: {activeInvoice.date.replace('T', ' ')}</p>
                </div>
              </div>

              {/* Billed To / Customer Info Box */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-300 text-xs text-slate-950">
                <div>
                  <span className="text-[10px] font-extrabold text-slate-950 uppercase block mb-1">Billed To (ক্রেতার নাম ও ঠিকানা)</span>
                  <p className="font-bold text-slate-950 text-sm">{activeInvoice.wholesalerName}</p>
                  <p className="text-slate-900 mt-0.5 font-normal">Phone: <span className="font-medium text-slate-950">{activeCustomer?.phone || 'N/A'}</span></p>
                  <p className="text-slate-900 mt-0.5 font-normal">Address: <span className="font-medium text-slate-950">{activeCustomer?.address || 'N/A'}</span></p>
                </div>

                <div className="text-right flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold text-slate-950 uppercase block mb-1">Payment Status</span>
                    <span className={`inline-block px-2.5 py-0.5 rounded text-xs font-extrabold uppercase ${
                      activeInvoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-900 border border-emerald-400' :
                      activeInvoice.status === 'Partial' ? 'bg-amber-100 text-amber-900 border border-amber-400' :
                      'bg-rose-100 text-rose-900 border border-rose-400'
                    }`}>
                      {activeInvoice.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-900 font-medium italic">Authorized Memo Document</p>
                </div>
              </div>

              {/* Products Table */}
              <div className="overflow-hidden border border-slate-400 rounded-xl">
                <table className="w-full text-left text-sm text-slate-950">
                  <thead className="bg-slate-100 text-slate-950 font-extrabold uppercase tracking-wider text-xs border-b border-slate-400">
                    <tr>
                      <th className="p-3.5 border-r border-slate-400 text-center w-14 whitespace-nowrap text-slate-950">SL</th>
                      <th className="p-3.5 border-r border-slate-400 whitespace-nowrap text-slate-950">Product / Item Description</th>
                      <th className="p-3.5 border-r border-slate-400 text-center w-28 whitespace-nowrap text-slate-950">Quantity</th>
                      <th className="p-3.5 border-r border-slate-400 text-center w-32 whitespace-nowrap text-slate-950">Rate ({formatCurrSymbol(currency)})</th>
                      <th className="p-3.5 text-center w-36 whitespace-nowrap text-slate-950">Amount ({formatCurrSymbol(currency)})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300">
                    {activeInvoice.items.map((item, index) => (
                      <tr key={index}>
                        <td className="p-3.5 border-r border-slate-300 text-center font-medium text-slate-950">{index + 1}</td>
                        <td className="p-3.5 border-r border-slate-300 font-semibold text-slate-950">{item.itemName}</td>
                        <td className="p-3.5 border-r border-slate-300 text-center font-semibold text-slate-950">{item.quantity}</td>
                        <td className="p-3.5 border-r border-slate-300 text-center font-mono font-semibold text-slate-950">{formatCurrSymbol(currency)} {item.unitPrice.toLocaleString()}</td>
                        <td className="p-3.5 text-center font-mono font-bold text-slate-950">{formatCurrSymbol(currency)} {item.total.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals Summary */}
              <div className="flex justify-end pt-2">
                <div className="w-80 space-y-2.5 text-sm border border-slate-400 rounded-xl p-4 bg-slate-50 text-slate-950">
                  <div className="flex justify-between text-slate-950">
                    <span className="font-bold">Total Bill:</span>
                    <span className="font-mono font-extrabold text-slate-950">{formatCurrSymbol(currency)} {activeInvoice.totalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-emerald-800">
                    <span className="font-bold">Cash Advance / Paid:</span>
                    <span className="font-mono font-extrabold">{formatCurrSymbol(currency)} {activeInvoice.paidAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-rose-800 pt-2.5 border-t border-slate-400 text-base">
                    <span className="font-extrabold">Net Due Remaining:</span>
                    <span className="font-mono font-black">{formatCurrSymbol(currency)} {activeInvoice.dueAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Signatures & Note */}
              <div className="pt-12 flex justify-between items-end text-xs text-slate-950">
                <div className="text-center">
                  <div className="w-36 border-b-2 border-slate-900 mb-1"></div>
                  <span className="font-medium text-slate-950">Customer Signature</span>
                </div>
                <div className="text-center">
                  <div className="w-36 border-b-2 border-slate-900 mb-1"></div>
                  <span className="font-medium text-slate-950">Authorized Signature</span>
                </div>
              </div>

              <div className="text-center text-xs text-slate-900 pt-4 border-t border-slate-300 font-medium">
                Thank you for your business with {brandName}! • System Generated Invoice
              </div>

            </div>

          </div>
        </div>
      )}

      {/* --- EDIT CHALAN MODAL --- */}
      {editingInvoice && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full p-6 sm:p-8 space-y-5 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2 font-extrabold text-slate-800 text-lg">
                <Edit className="w-5 h-5 text-amber-500" />
                <span>Edit Chalan: {editingInvoice.chalanNo}</span>
              </div>
              <button
                type="button"
                onClick={() => setEditingInvoice(null)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Customer & Date Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Customer / Wholesaler</label>
                  <select
                    value={editWholesalerId}
                    onChange={e => setEditWholesalerId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="">-- Select Customer --</option>
                    {wholesalers.map(w => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Chalan Date</label>
                  <input
                    type="date"
                    required
                    value={editChalanDate}
                    onChange={e => setEditChalanDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Add Item Row */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <p className="text-xs font-bold text-slate-700 uppercase mb-2">Add Additional Product to Order</p>
                <form onSubmit={handleEditAddToCart} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-2">
                    <select
                      value={editSelectedItemId}
                      onChange={e => setEditSelectedItemId(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="">-- Choose Item --</option>
                      {items.map(i => (
                        <option key={i.id} value={i.id}>{i.name} ({currency}{i.price})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <input
                      type="number" min="1"
                      placeholder="Qty"
                      value={editQty}
                      onChange={e => setEditQty(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold px-3 py-2 rounded-xl text-xs flex justify-center items-center gap-1 transition"
                  >
                    <Plus className="w-4 h-4" /> Add
                  </button>
                </form>
              </div>

              {/* Items List in Cart */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3">Product Name</th>
                      <th className="p-3 text-center w-28">Quantity</th>
                      <th className="p-3 text-right">Unit Price</th>
                      <th className="p-3 text-right">Total</th>
                      <th className="p-3 text-center w-12">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {editCart.map(c => (
                      <tr key={c.itemId} className="hover:bg-slate-50">
                        <td className="p-3 font-bold text-slate-900">{c.itemName}</td>
                        <td className="p-3 text-center">
                          <input
                            type="number"
                            min="1"
                            value={c.quantity}
                            onChange={(e) => {
                              const newQ = Number(e.target.value) || 1;
                              setEditCart(editCart.map(item => item.itemId === c.itemId ? { ...item, quantity: newQ, total: newQ * item.unitPrice } : item));
                            }}
                            className="w-20 bg-slate-100 border border-slate-300 rounded-lg px-2 py-1 text-center text-xs font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                          />
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-800">{formatCurrSymbol(currency)} {c.unitPrice}</td>
                        <td className="p-3 text-right font-mono font-extrabold text-slate-900">{formatCurrSymbol(currency)} {c.total.toLocaleString()}</td>
                        <td className="p-3 text-center">
                          <button
                            type="button"
                            onClick={() => removeEditCartItem(c.itemId)}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {editCart.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-slate-400">Cart is empty. Please add items.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Edit Totals Summary */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex justify-between items-center text-sm font-bold text-slate-800">
                  <span>Grand Total:</span>
                  <span className="font-mono text-base">{formatCurrSymbol(currency)} {editCart.reduce((s, i) => s + i.total, 0).toLocaleString()}</span>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Advance / Paid Amount:</label>
                  <input
                    type="number"
                    min="0"
                    value={editPaidAmount}
                    onChange={(e) => setEditPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-36 bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-500 text-right"
                  />
                </div>

                <div className="flex justify-between items-center text-sm font-extrabold text-rose-700 pt-2 border-t border-slate-200">
                  <span>Due Remaining:</span>
                  <span className="font-mono">{formatCurrSymbol(currency)} {Math.max(0, editCart.reduce((s, i) => s + i.total, 0) - (Number(editPaidAmount) || 0)).toLocaleString()}</span>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingInvoice(null)}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveEditInvoice}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs shadow-md transition"
                >
                  Save & Update Chalan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRINT CSS STYLES */}
      <style>{`
        @media print {
          @page {
            size: A4 portrait;
            margin: 10mm 12mm;
          }
          html, body {
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            height: auto !important;
            overflow: visible !important;
          }
          body * {
            visibility: hidden !important;
          }
          #printable-chalan, #printable-chalan * {
            visibility: visible !important;
          }
          #printable-chalan {
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 20px !important;
            box-shadow: none !important;
            border: 1px solid #94a3b8 !important;
            border-radius: 12px !important;
            background: #ffffff !important;
            color: #020617 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
};
